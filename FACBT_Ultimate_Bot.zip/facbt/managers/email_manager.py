"""
Email Manager - Handles temporary email creation and management with custom email support
"""

import asyncio
import time
import re
from typing import Dict, List, Optional, Any, Union
from dataclasses import dataclass
from enum import Enum
import json

from services.email_services.tempmail_org import TempMailOrgService
from services.email_services.mail_tm import MailTmService
from services.email_services.guerrilla_mail import GuerrillaMailService
from utils.logger import LoggerFactory


class EmailServiceType(Enum):
    """Email service types"""
    TEMPMAIL_ORG = "tempmail_org"
    MAIL_TM = "mail_tm"
    GUERRILLA_MAIL = "guerrilla_mail"
    CUSTOM = "custom"


@dataclass
class EmailAddress:
    """Email address data structure"""
    address: str
    service_type: EmailServiceType
    created_at: float
    expires_at: Optional[float] = None
    service_data: Optional[Dict[str, Any]] = None


@dataclass
class EmailMessage:
    """Email message data structure"""
    id: str
    sender: str
    subject: str
    body: str
    received_at: float
    verification_code: Optional[str] = None


@dataclass
class CustomEmailConfig:
    """Custom email configuration"""
    email: str
    password: Optional[str] = None
    imap_server: Optional[str] = None
    imap_port: Optional[int] = None
    smtp_server: Optional[str] = None
    smtp_port: Optional[int] = None
    use_manual_verification: bool = True


class EmailManager:
    """Manages temporary email addresses and verification"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # Email services
        self.services: Dict[EmailServiceType, Any] = {}
        self.active_emails: Dict[str, EmailAddress] = {}
        
        # Custom email support
        self.custom_emails: Dict[str, CustomEmailConfig] = {}
        self.manual_verification_codes: Dict[str, str] = {}
        
        # Service rotation
        self.service_rotation_index = 0
        self.service_failures: Dict[EmailServiceType, int] = {}
        
    async def initialize(self):
        """Initialize email services"""
        try:
            self.logger.info("Initializing Email Manager...")
            
            # Initialize automatic services
            await self._initialize_services()
            
            # Load custom emails if configured
            await self._load_custom_emails()
            
            self.logger.info("Email Manager initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize Email Manager: {e}")
            raise
            
    async def _initialize_services(self):
        """Initialize email service providers"""
        services_config = self.config.get('services', {})
        
        # TempMail.org
        if services_config.get('tempmail_org', {}).get('enabled', True):
            try:
                self.services[EmailServiceType.TEMPMAIL_ORG] = TempMailOrgService(
                    services_config.get('tempmail_org', {})
                )
                await self.services[EmailServiceType.TEMPMAIL_ORG].initialize()
                self.logger.info("✅ TempMail.org service initialized")
            except Exception as e:
                self.logger.warning(f"⚠️ Failed to initialize TempMail.org: {e}")
                
        # Mail.tm
        if services_config.get('mail_tm', {}).get('enabled', True):
            try:
                self.services[EmailServiceType.MAIL_TM] = MailTmService(
                    services_config.get('mail_tm', {})
                )
                await self.services[EmailServiceType.MAIL_TM].initialize()
                self.logger.info("✅ Mail.tm service initialized")
            except Exception as e:
                self.logger.warning(f"⚠️ Failed to initialize Mail.tm: {e}")
                
        # Guerrilla Mail
        if services_config.get('guerrilla_mail', {}).get('enabled', True):
            try:
                self.services[EmailServiceType.GUERRILLA_MAIL] = GuerrillaMailService(
                    services_config.get('guerrilla_mail', {})
                )
                await self.services[EmailServiceType.GUERRILLA_MAIL].initialize()
                self.logger.info("✅ Guerrilla Mail service initialized")
            except Exception as e:
                self.logger.warning(f"⚠️ Failed to initialize Guerrilla Mail: {e}")
                
    async def _load_custom_emails(self):
        """Load custom email configurations"""
        custom_config = self.config.get('custom_emails', {})
        
        if custom_config.get('enabled', False):
            emails_list = custom_config.get('emails', [])
            
            for email_config in emails_list:
                if isinstance(email_config, str):
                    # Simple email string
                    self.custom_emails[email_config] = CustomEmailConfig(
                        email=email_config,
                        use_manual_verification=True
                    )
                elif isinstance(email_config, dict):
                    # Full email configuration
                    email_addr = email_config.get('email')
                    if email_addr:
                        self.custom_emails[email_addr] = CustomEmailConfig(
                            email=email_addr,
                            password=email_config.get('password'),
                            imap_server=email_config.get('imap_server'),
                            imap_port=email_config.get('imap_port', 993),
                            smtp_server=email_config.get('smtp_server'),
                            smtp_port=email_config.get('smtp_port', 587),
                            use_manual_verification=email_config.get('use_manual_verification', True)
                        )
                        
            self.logger.info(f"Loaded {len(self.custom_emails)} custom email configurations")
            
    async def create_email(self, service_type: Optional[EmailServiceType] = None, 
                          custom_email: Optional[str] = None) -> EmailAddress:
        """Create a new email address"""
        try:
            # Handle custom email
            if service_type == EmailServiceType.CUSTOM or custom_email:
                return await self._create_custom_email(custom_email)
                
            # Handle automatic service selection
            if not service_type:
                service_type = await self._select_best_service()
                
            if service_type not in self.services:
                raise ValueError(f"Service {service_type} not available")
                
            service = self.services[service_type]
            email_data = await service.create_email()
            
            email_address = EmailAddress(
                address=email_data['email'],
                service_type=service_type,
                created_at=time.time(),
                expires_at=email_data.get('expires_at'),
                service_data=email_data
            )
            
            self.active_emails[email_address.address] = email_address
            self.logger.info(f"Created email: {email_address.address} via {service_type.value}")
            
            return email_address
            
        except Exception as e:
            self.logger.error(f"Failed to create email: {e}")
            raise
            
    async def _create_custom_email(self, email: Optional[str] = None) -> EmailAddress:
        """Create custom email address"""
        if email:
            # Use provided email
            if email not in self.custom_emails:
                # Add as new custom email
                self.custom_emails[email] = CustomEmailConfig(
                    email=email,
                    use_manual_verification=True
                )
        else:
            # Select from configured custom emails
            if not self.custom_emails:
                raise ValueError("No custom emails configured")
            email = list(self.custom_emails.keys())[0]  # Use first available
            
        email_address = EmailAddress(
            address=email,
            service_type=EmailServiceType.CUSTOM,
            created_at=time.time(),
            service_data={'custom_config': self.custom_emails[email]}
        )
        
        self.active_emails[email] = email_address
        self.logger.info(f"Using custom email: {email}")
        
        return email_address
        
    async def _select_best_service(self) -> EmailServiceType:
        """Select the best available email service"""
        available_services = [
            service_type for service_type in self.services.keys()
            if self.service_failures.get(service_type, 0) < 3
        ]
        
        if not available_services:
            # Reset failure counts if all services failed
            self.service_failures.clear()
            available_services = list(self.services.keys())
            
        if not available_services:
            raise RuntimeError("No email services available")
            
        # Round-robin selection
        service_type = available_services[self.service_rotation_index % len(available_services)]
        self.service_rotation_index += 1
        
        return service_type
        
    async def get_verification_code(self, email_address: EmailAddress, 
                                  timeout: int = 300) -> Optional[str]:
        """Get verification code from email"""
        try:
            if email_address.service_type == EmailServiceType.CUSTOM:
                return await self._get_custom_verification_code(email_address, timeout)
            else:
                return await self._get_automatic_verification_code(email_address, timeout)
                
        except Exception as e:
            self.logger.error(f"Failed to get verification code: {e}")
            return None
            
    async def _get_custom_verification_code(self, email_address: EmailAddress, 
                                          timeout: int) -> Optional[str]:
        """Get verification code for custom email"""
        custom_config = email_address.service_data.get('custom_config')
        
        if custom_config.use_manual_verification:
            # Manual verification code input
            return await self._prompt_manual_verification_code(email_address.address)
        else:
            # Automatic verification via IMAP
            return await self._get_imap_verification_code(email_address, timeout)
            
    async def _prompt_manual_verification_code(self, email: str) -> Optional[str]:
        """Prompt user for manual verification code input"""
        self.logger.info(f"📧 Manual verification required for: {email}")
        
        # Check if code already provided
        if email in self.manual_verification_codes:
            code = self.manual_verification_codes.pop(email)
            self.logger.info(f"✅ Using provided verification code for {email}")
            return code
            
        # Interactive prompt for verification code
        print(f"\n🔐 VERIFICATION CODE REQUIRED")
        print(f"📧 Email: {email}")
        print(f"📱 Please check your email and enter the verification code below:")
        print(f"💡 You can also use set_verification_code('{email}', 'CODE') method")
        
        # Wait for manual input or pre-set code
        timeout_start = time.time()
        while time.time() - timeout_start < 300:  # 5 minute timeout
            if email in self.manual_verification_codes:
                code = self.manual_verification_codes.pop(email)
                self.logger.info(f"✅ Received verification code for {email}")
                return code
                
            # Check for console input (if available)
            try:
                import sys
                import select
                if sys.stdin in select.select([sys.stdin], [], [], 1)[0]:
                    code = input().strip()
                    if code:
                        self.logger.info(f"✅ Manual verification code entered for {email}")
                        return code
            except:
                pass
                
            await asyncio.sleep(1)
            
        self.logger.warning(f"⏰ Verification code timeout for {email}")
        return None
        
    async def _get_imap_verification_code(self, email_address: EmailAddress, 
                                        timeout: int) -> Optional[str]:
        """Get verification code via IMAP"""
        custom_config = email_address.service_data.get('custom_config')
        
        if not all([custom_config.password, custom_config.imap_server]):
            self.logger.warning("IMAP credentials not configured, falling back to manual verification")
            return await self._prompt_manual_verification_code(email_address.address)
            
        try:
            import imaplib
            import email
            from email.header import decode_header
            
            # Connect to IMAP server
            mail = imaplib.IMAP4_SSL(custom_config.imap_server, custom_config.imap_port)
            mail.login(email_address.address, custom_config.password)
            mail.select('inbox')
            
            timeout_start = time.time()
            while time.time() - timeout_start < timeout:
                # Search for Facebook emails
                status, messages = mail.search(None, 'FROM', 'facebook.com')
                
                if status == 'OK' and messages[0]:
                    # Get the latest message
                    latest_email_id = messages[0].split()[-1]
                    status, msg_data = mail.fetch(latest_email_id, '(RFC822)')
                    
                    if status == 'OK':
                        email_body = msg_data[0][1]
                        email_message = email.message_from_bytes(email_body)
                        
                        # Extract verification code
                        code = self._extract_verification_code_from_email(email_message)
                        if code:
                            mail.logout()
                            return code
                            
                await asyncio.sleep(10)  # Check every 10 seconds
                
            mail.logout()
            
        except Exception as e:
            self.logger.error(f"IMAP verification failed: {e}")
            return await self._prompt_manual_verification_code(email_address.address)
            
        return None
        
    async def _get_automatic_verification_code(self, email_address: EmailAddress, 
                                             timeout: int) -> Optional[str]:
        """Get verification code from automatic email service"""
        service = self.services[email_address.service_type]
        
        timeout_start = time.time()
        while time.time() - timeout_start < timeout:
            try:
                messages = await service.get_messages(email_address.service_data)
                
                for message in messages:
                    # Look for Facebook verification emails
                    if 'facebook' in message.get('sender', '').lower():
                        code = self._extract_verification_code_from_text(
                            message.get('body', '') + ' ' + message.get('subject', '')
                        )
                        if code:
                            self.logger.info(f"✅ Found verification code: {code}")
                            return code
                            
                await asyncio.sleep(10)  # Check every 10 seconds
                
            except Exception as e:
                self.logger.warning(f"Error checking messages: {e}")
                await asyncio.sleep(15)
                
        return None
        
    def _extract_verification_code_from_email(self, email_message) -> Optional[str]:
        """Extract verification code from email message"""
        try:
            # Get email body
            body = ""
            if email_message.is_multipart():
                for part in email_message.walk():
                    if part.get_content_type() == "text/plain":
                        body += part.get_payload(decode=True).decode()
            else:
                body = email_message.get_payload(decode=True).decode()
                
            return self._extract_verification_code_from_text(body)
            
        except Exception as e:
            self.logger.error(f"Error extracting code from email: {e}")
            return None
            
    def _extract_verification_code_from_text(self, text: str) -> Optional[str]:
        """Extract verification code from text using regex patterns"""
        # Common verification code patterns
        patterns = [
            r'\b(\d{6})\b',  # 6-digit code
            r'\b(\d{5})\b',  # 5-digit code
            r'\b(\d{4})\b',  # 4-digit code
            r'code[:\s]+(\d+)',  # "code: 123456"
            r'verification[:\s]+(\d+)',  # "verification: 123456"
            r'confirm[:\s]+(\d+)',  # "confirm: 123456"
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, text, re.IGNORECASE)
            if matches:
                # Return the first match that looks like a verification code
                for match in matches:
                    if len(match) >= 4 and len(match) <= 8:
                        return match
                        
        return None
        
    def set_verification_code(self, email: str, code: str):
        """Manually set verification code for an email"""
        self.manual_verification_codes[email] = code
        self.logger.info(f"📝 Verification code set for {email}")
        
    def add_custom_email(self, email: str, password: Optional[str] = None,
                        imap_server: Optional[str] = None, imap_port: int = 993,
                        use_manual_verification: bool = True):
        """Add a custom email configuration"""
        self.custom_emails[email] = CustomEmailConfig(
            email=email,
            password=password,
            imap_server=imap_server,
            imap_port=imap_port,
            use_manual_verification=use_manual_verification
        )
        self.logger.info(f"➕ Added custom email: {email}")
        
    def list_custom_emails(self) -> List[str]:
        """List all configured custom emails"""
        return list(self.custom_emails.keys())
        
    def show_email_functions(self):
        """Show available email functions for custom configuration"""
        print("\n📧 CUSTOM EMAIL FUNCTIONS")
        print("=" * 50)
        print("🔧 Available Functions:")
        print()
        print("1. add_custom_email(email, password=None, imap_server=None)")
        print("   📝 Add a custom email for account creation")
        print("   📧 Example: add_custom_email('myemail@gmail.com', 'password', 'imap.gmail.com')")
        print()
        print("2. set_verification_code(email, code)")
        print("   🔐 Set verification code manually")
        print("   📱 Example: set_verification_code('myemail@gmail.com', '123456')")
        print()
        print("3. list_custom_emails()")
        print("   📋 List all configured custom emails")
        print()
        print("4. create_email(service_type=EmailServiceType.CUSTOM, custom_email='email@domain.com')")
        print("   ✉️ Create email using custom configuration")
        print()
        print("💡 USAGE EXAMPLES:")
        print("   # Add your confirmed email")
        print("   email_manager.add_custom_email('confirmed@gmail.com')")
        print()
        print("   # Set verification code when prompted")
        print("   email_manager.set_verification_code('confirmed@gmail.com', '123456')")
        print()
        print("   # Use custom email for account creation")
        print("   email = await email_manager.create_email(EmailServiceType.CUSTOM)")
        print()
        
    async def cleanup_email(self, email_address: EmailAddress):
        """Cleanup email resources"""
        try:
            if email_address.address in self.active_emails:
                del self.active_emails[email_address.address]
                
            if email_address.service_type != EmailServiceType.CUSTOM:
                service = self.services.get(email_address.service_type)
                if service and hasattr(service, 'cleanup_email'):
                    await service.cleanup_email(email_address.service_data)
                    
            self.logger.info(f"🧹 Cleaned up email: {email_address.address}")
            
        except Exception as e:
            self.logger.warning(f"Email cleanup error: {e}")
            
    async def health_check(self) -> bool:
        """Check health of email services"""
        try:
            healthy_services = 0
            total_services = len(self.services)
            
            for service_type, service in self.services.items():
                try:
                    if hasattr(service, 'health_check'):
                        if await service.health_check():
                            healthy_services += 1
                    else:
                        healthy_services += 1
                except Exception as e:
                    self.logger.warning(f"Health check failed for {service_type}: {e}")
                    
            # Consider healthy if at least one service works or custom emails available
            is_healthy = healthy_services > 0 or len(self.custom_emails) > 0
            
            self.logger.info(f"Email Manager health: {healthy_services}/{total_services} services + {len(self.custom_emails)} custom emails")
            return is_healthy
            
        except Exception as e:
            self.logger.error(f"Health check error: {e}")
            return False
            
    async def get_services_status(self) -> Dict[str, Any]:
        """Get status of all email services"""
        status = {
            'automatic_services': {},
            'custom_emails': {
                'count': len(self.custom_emails),
                'emails': list(self.custom_emails.keys())
            },
            'active_emails': len(self.active_emails),
            'manual_codes_pending': len(self.manual_verification_codes)
        }
        
        for service_type, service in self.services.items():
            try:
                if hasattr(service, 'get_status'):
                    status['automatic_services'][service_type.value] = await service.get_status()
                else:
                    status['automatic_services'][service_type.value] = {'status': 'available'}
            except Exception as e:
                status['automatic_services'][service_type.value] = {'status': 'error', 'error': str(e)}
                
        return status
        
    async def stop(self):
        """Stop email manager and cleanup resources"""
        try:
            self.logger.info("Stopping Email Manager...")
            
            # Cleanup active emails
            for email_address in list(self.active_emails.values()):
                await self.cleanup_email(email_address)
                
            # Stop services
            for service in self.services.values():
                if hasattr(service, 'stop'):
                    await service.stop()
                    
            self.logger.info("Email Manager stopped successfully")
            
        except Exception as e:
            self.logger.error(f"Error stopping Email Manager: {e}")


# Convenience functions for interactive use
def show_email_functions():
    """Show email functions help"""
    EmailManager({}).show_email_functions()


# Global email manager instance for interactive use
_global_email_manager = None

def get_email_manager():
    """Get global email manager instance"""
    global _global_email_manager
    if _global_email_manager is None:
        _global_email_manager = EmailManager({})
    return _global_email_manager

def add_custom_email(email: str, password: Optional[str] = None, 
                    imap_server: Optional[str] = None, use_manual: bool = True):
    """Add custom email (convenience function)"""
    manager = get_email_manager()
    manager.add_custom_email(email, password, imap_server, use_manual_verification=use_manual)

def set_verification_code(email: str, code: str):
    """Set verification code (convenience function)"""
    manager = get_email_manager()
    manager.set_verification_code(email, code)

def list_custom_emails():
    """List custom emails (convenience function)"""
    manager = get_email_manager()
    return manager.list_custom_emails()

