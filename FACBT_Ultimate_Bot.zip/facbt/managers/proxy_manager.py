"""
Proxy Manager - Manages free proxy rotation and validation
"""

import asyncio
import aiohttp
import time
import random
from typing import Dict, List, Optional, Any, Set
from dataclasses import dataclass
from enum import Enum
import json
from pathlib import Path

from utils.logger import LoggerFactory


class ProxyType(Enum):
    """Proxy protocol types"""
    HTTP = "http"
    HTTPS = "https"
    SOCKS4 = "socks4"
    SOCKS5 = "socks5"


class AnonymityLevel(Enum):
    """Proxy anonymity levels"""
    TRANSPARENT = "transparent"
    ANONYMOUS = "anonymous"
    ELITE = "elite"


@dataclass
class Proxy:
    """Proxy data structure"""
    host: str
    port: int
    protocol: ProxyType
    country: Optional[str] = None
    anonymity: Optional[AnonymityLevel] = None
    response_time: Optional[float] = None
    last_checked: Optional[float] = None
    failure_count: int = 0
    success_count: int = 0
    is_working: bool = True
    
    @property
    def url(self) -> str:
        """Get proxy URL"""
        return f"{self.protocol.value}://{self.host}:{self.port}"
        
    @property
    def success_rate(self) -> float:
        """Calculate success rate"""
        total = self.success_count + self.failure_count
        return (self.success_count / total) if total > 0 else 0.0
        
    def __str__(self) -> str:
        return f"{self.host}:{self.port}"


class ProxyManager:
    """Manages proxy pool and rotation"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # Proxy pools
        self.proxy_pool: List[Proxy] = []
        self.working_proxies: List[Proxy] = []
        self.failed_proxies: Set[str] = set()
        
        # Configuration
        self.pool_size = config.get('pool_size', 100)
        self.min_pool_size = config.get('min_pool_size', 20)
        self.validation_timeout = config.get('validation_timeout', 10)
        self.max_failures = config.get('max_failures_per_proxy', 3)
        
        # Rotation
        self.rotation_index = 0
        self.rotation_strategy = config.get('rotation_strategy', 'round_robin')
        
        # Country preferences
        self.preferred_countries = set(config.get('preferred_countries', []))
        self.blacklisted_countries = set(config.get('blacklisted_countries', []))
        
        # Services
        self.proxy_sources = []
        self.last_refresh = 0
        self.refresh_interval = config.get('proxy_refresh_interval', 3600)
        
    async def initialize(self):
        """Initialize proxy manager"""
        try:
            self.logger.info("Initializing Proxy Manager...")
            
            # Initialize proxy sources
            await self._initialize_proxy_sources()
            
            # Load initial proxy pool
            await self._refresh_proxy_pool()
            
            # Start background tasks
            asyncio.create_task(self._background_validation())
            asyncio.create_task(self._background_refresh())
            
            self.logger.info(f"Proxy Manager initialized with {len(self.working_proxies)} working proxies")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize Proxy Manager: {e}")
            raise
            
    async def _initialize_proxy_sources(self):
        """Initialize proxy source services from top worldwide free proxy sites"""
        services_config = self.config.get('services', {})
        
        # Add all major free proxy sources automatically
        self.proxy_sources = [
            # Top-tier proxy sources
            self._fetch_proxyscrape_proxies,
            self._fetch_free_proxy_list_proxies,
            self._fetch_proxy_list_download_proxies,
            self._fetch_proxylist_geonode_proxies,
            self._fetch_github_proxy_sources,
            
            # International proxy sources
            self._fetch_spys_one_proxies,
            self._fetch_hidemy_name_proxies,
            self._fetch_proxy_daily_proxies,
            self._fetch_cool_proxy_proxies,
            self._fetch_proxy_nova_proxies,
            
            # Regional proxy sources
            self._fetch_us_proxy_sources,
            self._fetch_eu_proxy_sources,
            self._fetch_asia_proxy_sources,
            self._fetch_global_proxy_sources,
            
            # Additional sources
            self._fetch_proxy_fish_proxies,
            self._fetch_advanced_name_proxies,
            self._fetch_proxy_space_proxies,
            self._fetch_proxy_sail_proxies,
            self._fetch_proxy_rotator_proxies
        ]
        
        self.logger.info(f"Initialized {len(self.proxy_sources)} worldwide proxy sources")
        
    async def _refresh_proxy_pool(self):
        """Refresh the proxy pool from all sources"""
        try:
            self.logger.info("Refreshing proxy pool...")
            
            new_proxies = []
            
            # Fetch from all sources
            for source in self.proxy_sources:
                try:
                    proxies = await source()
                    new_proxies.extend(proxies)
                    self.logger.debug(f"Fetched {len(proxies)} proxies from {source.__name__}")
                except Exception as e:
                    self.logger.warning(f"Failed to fetch from {source.__name__}: {e}")
                    
            # Remove duplicates
            unique_proxies = {}
            for proxy in new_proxies:
                key = f"{proxy.host}:{proxy.port}"
                if key not in unique_proxies:
                    unique_proxies[key] = proxy
                    
            self.proxy_pool = list(unique_proxies.values())
            self.logger.info(f"Collected {len(self.proxy_pool)} unique proxies")
            
            # Validate proxies
            await self._validate_proxy_pool()
            
            self.last_refresh = time.time()
            
        except Exception as e:
            self.logger.error(f"Failed to refresh proxy pool: {e}")
            
    async def _validate_proxy_pool(self):
        """Validate all proxies in the pool"""
        self.logger.info("Validating proxy pool...")
        
        # Limit concurrent validations
        semaphore = asyncio.Semaphore(20)
        
        async def validate_proxy(proxy):
            async with semaphore:
                is_working = await self._validate_proxy(proxy)
                if is_working:
                    self.working_proxies.append(proxy)
                    
        # Validate all proxies
        tasks = [validate_proxy(proxy) for proxy in self.proxy_pool]
        await asyncio.gather(*tasks, return_exceptions=True)
        
        # Filter by preferences
        self._filter_proxies_by_preferences()
        
        self.logger.info(f"Validation complete: {len(self.working_proxies)} working proxies")
        
    async def _validate_proxy(self, proxy: Proxy) -> bool:
        """Validate a single proxy"""
        try:
            start_time = time.time()
            
            # Test URLs
            test_urls = [
                'http://httpbin.org/ip',
                'https://api.ipify.org?format=json',
                'http://ip-api.com/json'
            ]
            
            connector = aiohttp.TCPConnector(limit=1)
            timeout = aiohttp.ClientTimeout(total=self.validation_timeout)
            
            async with aiohttp.ClientSession(
                connector=connector,
                timeout=timeout
            ) as session:
                
                for test_url in test_urls:
                    try:
                        async with session.get(
                            test_url,
                            proxy=proxy.url,
                            ssl=False
                        ) as response:
                            if response.status == 200:
                                proxy.response_time = time.time() - start_time
                                proxy.last_checked = time.time()
                                proxy.success_count += 1
                                proxy.is_working = True
                                
                                # Try to get IP info
                                try:
                                    data = await response.json()
                                    if 'country' in data:
                                        proxy.country = data['country']
                                except:
                                    pass
                                    
                                return True
                    except:
                        continue
                        
            # All tests failed
            proxy.failure_count += 1
            proxy.is_working = False
            return False
            
        except Exception as e:
            proxy.failure_count += 1
            proxy.is_working = False
            return False
            
    def _filter_proxies_by_preferences(self):
        """Filter proxies based on country preferences"""
        if not self.preferred_countries and not self.blacklisted_countries:
            return
            
        filtered_proxies = []
        
        for proxy in self.working_proxies:
            # Skip if blacklisted country
            if proxy.country and proxy.country in self.blacklisted_countries:
                continue
                
            # Prefer specific countries if specified
            if self.preferred_countries:
                if proxy.country and proxy.country in self.preferred_countries:
                    filtered_proxies.append(proxy)
                elif not proxy.country:  # Include unknown countries
                    filtered_proxies.append(proxy)
            else:
                filtered_proxies.append(proxy)
                
        self.working_proxies = filtered_proxies
        self.logger.info(f"Filtered to {len(self.working_proxies)} preferred proxies")
        
    async def get_proxy(self, country: Optional[str] = None) -> Optional[Proxy]:
        """Get a working proxy"""
        try:
            # Check if we need to refresh
            if (time.time() - self.last_refresh > self.refresh_interval or 
                len(self.working_proxies) < self.min_pool_size):
                await self._refresh_proxy_pool()
                
            # Filter by country if specified
            candidates = self.working_proxies
            if country:
                candidates = [p for p in candidates if p.country == country]
                if not candidates:
                    candidates = self.working_proxies  # Fallback
                    
            if not candidates:
                self.logger.warning("No working proxies available")
                return None
                
            # Select proxy based on strategy
            if self.rotation_strategy == 'round_robin':
                proxy = candidates[self.rotation_index % len(candidates)]
                self.rotation_index += 1
            elif self.rotation_strategy == 'random':
                proxy = random.choice(candidates)
            elif self.rotation_strategy == 'weighted':
                proxy = self._select_weighted_proxy(candidates)
            else:
                proxy = random.choice(candidates)
                
            self.logger.debug(f"Selected proxy: {proxy}")
            return proxy
            
        except Exception as e:
            self.logger.error(f"Failed to get proxy: {e}")
            return None
            
    def _select_weighted_proxy(self, candidates: List[Proxy]) -> Proxy:
        """Select proxy based on success rate and response time"""
        if not candidates:
            return None
            
        # Calculate weights based on success rate and response time
        weights = []
        for proxy in candidates:
            success_weight = proxy.success_rate * 100
            speed_weight = max(0, 100 - (proxy.response_time or 10) * 10)
            total_weight = success_weight + speed_weight
            weights.append(max(1, total_weight))
            
        # Weighted random selection
        total_weight = sum(weights)
        r = random.uniform(0, total_weight)
        cumulative = 0
        
        for i, weight in enumerate(weights):
            cumulative += weight
            if r <= cumulative:
                return candidates[i]
                
        return candidates[-1]
        
    async def release_proxy(self, proxy: Proxy):
        """Release a proxy back to the pool"""
        # Mark as available (if needed for future pooling logic)
        pass
        
    async def report_proxy_failure(self, proxy: Proxy):
        """Report a proxy failure"""
        proxy.failure_count += 1
        proxy.is_working = False
        
        # Remove from working proxies if too many failures
        if proxy.failure_count >= self.max_failures:
            if proxy in self.working_proxies:
                self.working_proxies.remove(proxy)
            self.failed_proxies.add(f"{proxy.host}:{proxy.port}")
            
        self.logger.debug(f"Reported failure for proxy {proxy}")
        
    async def report_proxy_success(self, proxy: Proxy):
        """Report a proxy success"""
        proxy.success_count += 1
        proxy.is_working = True
        proxy.last_checked = time.time()
        
    # Proxy source implementations
    async def _fetch_proxyscrape_proxies(self) -> List[Proxy]:
        """Fetch proxies from ProxyScrape"""
        proxies = []
        
        try:
            urls = [
                'https://api.proxyscrape.com/v2/?request=get&protocol=http&timeout=10000&country=all&ssl=all&anonymity=all',
                'https://api.proxyscrape.com/v2/?request=get&protocol=socks4&timeout=10000&country=all',
                'https://api.proxyscrape.com/v2/?request=get&protocol=socks5&timeout=10000&country=all'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        protocol = ProxyType.HTTP
                                        if 'socks4' in url:
                                            protocol = ProxyType.SOCKS4
                                        elif 'socks5' in url:
                                            protocol = ProxyType.SOCKS5
                                            
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol,
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"ProxyScrape URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"ProxyScrape fetch failed: {e}")
            
        return proxies[:50]  # Limit to 50 proxies
        
    async def _fetch_free_proxy_list_proxies(self) -> List[Proxy]:
        """Fetch proxies from free-proxy-list.net"""
        proxies = []
        
        try:
            url = 'https://www.proxy-list.download/api/v1/get?type=http'
            
            async with aiohttp.ClientSession() as session:
                async with session.get(url, timeout=30) as response:
                    if response.status == 200:
                        text = await response.text()
                        for line in text.strip().split('\n'):
                            if ':' in line:
                                host, port = line.strip().split(':')
                                proxies.append(Proxy(
                                    host=host,
                                    port=int(port),
                                    protocol=ProxyType.HTTP,
                                    anonymity=AnonymityLevel.ANONYMOUS
                                ))
                                
        except Exception as e:
            self.logger.warning(f"Free proxy list fetch failed: {e}")
            
        return proxies[:30]
        
    async def _fetch_proxy_list_download_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy-list.download"""
        proxies = []
        
        try:
            urls = [
                'https://www.proxy-list.download/api/v1/get?type=http',
                'https://www.proxy-list.download/api/v1/get?type=https',
                'https://www.proxy-list.download/api/v1/get?type=socks4',
                'https://www.proxy-list.download/api/v1/get?type=socks5'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                protocol = ProxyType.HTTP
                                if 'socks4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'socks5' in url:
                                    protocol = ProxyType.SOCKS5
                                elif 'https' in url:
                                    protocol = ProxyType.HTTPS
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol
                                        ))
                    except Exception as e:
                        self.logger.debug(f"Proxy list download URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Proxy list download fetch failed: {e}")
            
        return proxies[:40]
        
    async def _fetch_proxylist_geonode_proxies(self) -> List[Proxy]:
        """Fetch proxies from ProxyList GeoNode"""
        proxies = []
        
        try:
            urls = [
                'https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc&protocols=http%2Chttps',
                'https://proxylist.geonode.com/api/proxy-list?limit=500&page=1&sort_by=lastChecked&sort_type=desc&protocols=socks4%2Csocks5'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                data = await response.json()
                                for item in data.get('data', []):
                                    protocols = item.get('protocols', ['http'])
                                    for protocol in protocols:
                                        proxy_type = ProxyType.HTTP
                                        if protocol == 'socks4':
                                            proxy_type = ProxyType.SOCKS4
                                        elif protocol == 'socks5':
                                            proxy_type = ProxyType.SOCKS5
                                        elif protocol == 'https':
                                            proxy_type = ProxyType.HTTPS
                                            
                                        proxies.append(Proxy(
                                            host=item.get('ip'),
                                            port=int(item.get('port')),
                                            protocol=proxy_type,
                                            country=item.get('country'),
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"GeoNode URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"GeoNode fetch failed: {e}")
            
        return proxies[:100]
        
    async def _fetch_github_proxy_sources(self) -> List[Proxy]:
        """Fetch proxies from GitHub proxy repositories"""
        proxies = []
        
        try:
            # Popular GitHub proxy repositories
            github_urls = [
                'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt',
                'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks4.txt',
                'https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/socks5.txt',
                'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt',
                'https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt',
                'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt',
                'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks4.txt',
                'https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/socks5.txt',
                'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
                'https://raw.githubusercontent.com/sunny9577/proxy-scraper/master/proxies.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in github_urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                # Determine protocol from URL
                                protocol = ProxyType.HTTP
                                if 'socks4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'socks5' in url:
                                    protocol = ProxyType.SOCKS5
                                elif 'https' in url:
                                    protocol = ProxyType.HTTPS
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line and not line.startswith('#'):
                                        parts = line.strip().split(':')
                                        if len(parts) >= 2:
                                            host, port = parts[0], parts[1]
                                            try:
                                                proxies.append(Proxy(
                                                    host=host,
                                                    port=int(port),
                                                    protocol=protocol,
                                                    anonymity=AnonymityLevel.ANONYMOUS
                                                ))
                                            except ValueError:
                                                continue
                    except Exception as e:
                        self.logger.debug(f"GitHub URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"GitHub proxy fetch failed: {e}")
            
        return proxies[:150]
        
    async def _fetch_spys_one_proxies(self) -> List[Proxy]:
        """Fetch proxies from spys.one"""
        proxies = []
        
        try:
            # Spys.one API endpoints
            urls = [
                'http://spys.one/en/free-proxy-list/',
                'http://spys.one/en/socks-proxy-list/',
                'http://spys.one/en/https-ssl-proxy/',
                'http://spys.one/en/anonymous-proxy-list/'
            ]
            
            # Note: spys.one requires more complex scraping
            # For now, we'll use a simplified approach
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                # Simple regex to find IP:PORT patterns
                                import re
                                pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{2,5})'
                                matches = re.findall(pattern, text)
                                
                                for host, port in matches[:50]:
                                    protocol = ProxyType.HTTP
                                    if 'socks' in url:
                                        protocol = ProxyType.SOCKS5
                                    elif 'https' in url:
                                        protocol = ProxyType.HTTPS
                                        
                                    proxies.append(Proxy(
                                        host=host,
                                        port=int(port),
                                        protocol=protocol,
                                        anonymity=AnonymityLevel.ANONYMOUS
                                    ))
                    except Exception as e:
                        self.logger.debug(f"Spys.one URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Spys.one fetch failed: {e}")
            
        return proxies[:100]
        
    async def _fetch_hidemy_name_proxies(self) -> List[Proxy]:
        """Fetch proxies from hidemy.name"""
        proxies = []
        
        try:
            # HideMyName proxy list
            urls = [
                'https://hidemy.name/en/proxy-list/?type=h#list',
                'https://hidemy.name/en/proxy-list/?type=s#list',
                'https://hidemy.name/en/proxy-list/?type=4#list',
                'https://hidemy.name/en/proxy-list/?type=5#list'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36'
                        }
                        async with session.get(url, headers=headers, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                # Parse HTML for proxy data
                                import re
                                pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})</td><td>(\d{2,5})'
                                matches = re.findall(pattern, text)
                                
                                for host, port in matches:
                                    protocol = ProxyType.HTTP
                                    if 'type=s' in url:
                                        protocol = ProxyType.HTTPS
                                    elif 'type=4' in url:
                                        protocol = ProxyType.SOCKS4
                                    elif 'type=5' in url:
                                        protocol = ProxyType.SOCKS5
                                        
                                    proxies.append(Proxy(
                                        host=host,
                                        port=int(port),
                                        protocol=protocol,
                                        anonymity=AnonymityLevel.ELITE
                                    ))
                    except Exception as e:
                        self.logger.debug(f"HideMyName URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"HideMyName fetch failed: {e}")
            
        return proxies[:80]
        
    async def _fetch_proxy_daily_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy-daily.com"""
        proxies = []
        
        try:
            urls = [
                'https://proxy-daily.com/',
                'https://www.proxy-daily.com/proxy-list',
                'https://proxy-daily.com/free-proxy-list'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                import re
                                pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{2,5})'
                                matches = re.findall(pattern, text)
                                
                                for host, port in matches:
                                    proxies.append(Proxy(
                                        host=host,
                                        port=int(port),
                                        protocol=ProxyType.HTTP,
                                        anonymity=AnonymityLevel.ANONYMOUS
                                    ))
                    except Exception as e:
                        self.logger.debug(f"Proxy Daily URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Proxy Daily fetch failed: {e}")
            
        return proxies[:60]
        
    async def _fetch_cool_proxy_proxies(self) -> List[Proxy]:
        """Fetch proxies from cool-proxy.net"""
        proxies = []
        
        try:
            urls = [
                'https://www.cool-proxy.net/proxies/http_proxy_list/sort:score/direction:desc',
                'https://www.cool-proxy.net/proxies/socks_proxy_list/sort:score/direction:desc'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                import re
                                pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})</td>\s*<td[^>]*>(\d{2,5})'
                                matches = re.findall(pattern, text)
                                
                                for host, port in matches:
                                    protocol = ProxyType.HTTP
                                    if 'socks' in url:
                                        protocol = ProxyType.SOCKS5
                                        
                                    proxies.append(Proxy(
                                        host=host,
                                        port=int(port),
                                        protocol=protocol,
                                        anonymity=AnonymityLevel.ANONYMOUS
                                    ))
                    except Exception as e:
                        self.logger.debug(f"Cool Proxy URL failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Cool Proxy fetch failed: {e}")
            
        return proxies[:50]
        
    async def _fetch_proxy_nova_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxynova.com"""
        proxies = []
        
        try:
            # ProxyNova country-specific lists
            countries = ['us', 'uk', 'ca', 'de', 'fr', 'nl', 'jp', 'kr', 'sg', 'au']
            
            async with aiohttp.ClientSession() as session:
                for country in countries:
                    try:
                        url = f'https://www.proxynova.com/proxy-server-list/country-{country}/'
                        headers = {
                            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                        }
                        async with session.get(url, headers=headers, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                import re
                                pattern = r'(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})</td><td[^>]*>(\d{2,5})'
                                matches = re.findall(pattern, text)
                                
                                for host, port in matches:
                                    proxies.append(Proxy(
                                        host=host,
                                        port=int(port),
                                        protocol=ProxyType.HTTP,
                                        country=country.upper(),
                                        anonymity=AnonymityLevel.ANONYMOUS
                                    ))
                    except Exception as e:
                        self.logger.debug(f"ProxyNova {country} failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"ProxyNova fetch failed: {e}")
            
        return proxies[:100]
        
    async def _fetch_us_proxy_sources(self) -> List[Proxy]:
        """Fetch proxies from US-specific sources"""
        proxies = []
        
        try:
            urls = [
                'https://raw.githubusercontent.com/proxy4parsing/proxy-list/main/http.txt',
                'https://api.openproxylist.xyz/http.txt',
                'https://raw.githubusercontent.com/ALIILAPRO/Proxy/main/http.txt',
                'https://raw.githubusercontent.com/prxchk/proxy-list/main/http.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=ProxyType.HTTP,
                                            country='US',
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"US proxy source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"US proxy sources fetch failed: {e}")
            
        return proxies[:80]
        
    async def _fetch_eu_proxy_sources(self) -> List[Proxy]:
        """Fetch proxies from European sources"""
        proxies = []
        
        try:
            urls = [
                'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-http.txt',
                'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-https.txt',
                'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks4.txt',
                'https://raw.githubusercontent.com/jetkai/proxy-list/main/online-proxies/txt/proxies-socks5.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                protocol = ProxyType.HTTP
                                if 'https' in url:
                                    protocol = ProxyType.HTTPS
                                elif 'socks4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'socks5' in url:
                                    protocol = ProxyType.SOCKS5
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol,
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"EU proxy source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"EU proxy sources fetch failed: {e}")
            
        return proxies[:100]
        
    async def _fetch_asia_proxy_sources(self) -> List[Proxy]:
        """Fetch proxies from Asian sources"""
        proxies = []
        
        try:
            urls = [
                'https://raw.githubusercontent.com/roosterkid/openproxylist/main/HTTPS_RAW.txt',
                'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS4_RAW.txt',
                'https://raw.githubusercontent.com/roosterkid/openproxylist/main/SOCKS5_RAW.txt',
                'https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt',
                'https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                protocol = ProxyType.HTTP
                                if 'HTTPS' in url or 'https' in url:
                                    protocol = ProxyType.HTTPS
                                elif 'SOCKS4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'SOCKS5' in url:
                                    protocol = ProxyType.SOCKS5
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol,
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"Asia proxy source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Asia proxy sources fetch failed: {e}")
            
        return proxies[:90]
        
    async def _fetch_global_proxy_sources(self) -> List[Proxy]:
        """Fetch proxies from global sources"""
        proxies = []
        
        try:
            urls = [
                'https://raw.githubusercontent.com/hookzof/socks5_list/master/proxy.txt',
                'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/http.txt',
                'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/https.txt',
                'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks4.txt',
                'https://raw.githubusercontent.com/rdavydov/proxy-list/main/proxies/socks5.txt',
                'https://api.proxyscrape.com/v2/?request=getproxies&protocol=all&timeout=10000&country=all&ssl=all&anonymity=all'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                protocol = ProxyType.HTTP
                                if 'https' in url:
                                    protocol = ProxyType.HTTPS
                                elif 'socks4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'socks5' in url:
                                    protocol = ProxyType.SOCKS5
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol,
                                            anonymity=AnonymityLevel.ANONYMOUS
                                        ))
                    except Exception as e:
                        self.logger.debug(f"Global proxy source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Global proxy sources fetch failed: {e}")
            
        return proxies[:120]
        
    async def _fetch_proxy_fish_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy-fish and similar services"""
        proxies = []
        
        try:
            urls = [
                'https://raw.githubusercontent.com/clarketm/proxy-list/master/proxy-list-raw.txt',
                'https://raw.githubusercontent.com/fate0/proxylist/master/proxy.list',
                'https://raw.githubusercontent.com/a2u/free-proxy-list/master/free-proxy-list.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                for line in text.strip().split('\n'):
                                    if ':' in line and not line.startswith('#'):
                                        parts = line.strip().split(':')
                                        if len(parts) >= 2:
                                            host, port = parts[0], parts[1]
                                            try:
                                                proxies.append(Proxy(
                                                    host=host,
                                                    port=int(port),
                                                    protocol=ProxyType.HTTP,
                                                    anonymity=AnonymityLevel.ANONYMOUS
                                                ))
                                            except ValueError:
                                                continue
                    except Exception as e:
                        self.logger.debug(f"Proxy fish source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Proxy fish sources fetch failed: {e}")
            
        return proxies[:70]
        
    async def _fetch_advanced_name_proxies(self) -> List[Proxy]:
        """Fetch proxies from advanced proxy services"""
        proxies = []
        
        try:
            # Multiple advanced proxy APIs
            urls = [
                'https://www.proxy-list.download/api/v1/get?type=http',
                'https://www.proxy-list.download/api/v1/get?type=https',
                'https://www.proxy-list.download/api/v1/get?type=socks4',
                'https://www.proxy-list.download/api/v1/get?type=socks5',
                'https://api.openproxylist.xyz/http.txt',
                'https://api.openproxylist.xyz/socks4.txt',
                'https://api.openproxylist.xyz/socks5.txt'
            ]
            
            async with aiohttp.ClientSession() as session:
                for url in urls:
                    try:
                        async with session.get(url, timeout=30) as response:
                            if response.status == 200:
                                text = await response.text()
                                
                                protocol = ProxyType.HTTP
                                if 'https' in url:
                                    protocol = ProxyType.HTTPS
                                elif 'socks4' in url:
                                    protocol = ProxyType.SOCKS4
                                elif 'socks5' in url:
                                    protocol = ProxyType.SOCKS5
                                    
                                for line in text.strip().split('\n'):
                                    if ':' in line:
                                        host, port = line.strip().split(':')
                                        proxies.append(Proxy(
                                            host=host,
                                            port=int(port),
                                            protocol=protocol,
                                            anonymity=AnonymityLevel.ELITE
                                        ))
                    except Exception as e:
                        self.logger.debug(f"Advanced proxy source failed: {e}")
                        
        except Exception as e:
            self.logger.warning(f"Advanced proxy sources fetch failed: {e}")
            
        return proxies[:80]
        
    async def _fetch_proxy_space_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy space services"""
        return []  # Placeholder for additional sources
        
    async def _fetch_proxy_sail_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy sail services"""
        return []  # Placeholder for additional sources
        
    async def _fetch_proxy_rotator_proxies(self) -> List[Proxy]:
        """Fetch proxies from proxy rotator services"""
        return []  # Placeholder for additional sources
        
    async def _background_validation(self):
        """Background task to validate proxies"""
        while True:
            try:
                await asyncio.sleep(300)  # Check every 5 minutes
                
                # Re-validate failed proxies
                failed_to_recheck = []
                for proxy in self.proxy_pool:
                    if not proxy.is_working and proxy.failure_count < self.max_failures:
                        failed_to_recheck.append(proxy)
                        
                if failed_to_recheck:
                    self.logger.info(f"Re-validating {len(failed_to_recheck)} failed proxies")
                    
                    semaphore = asyncio.Semaphore(10)
                    
                    async def revalidate_proxy(proxy):
                        async with semaphore:
                            if await self._validate_proxy(proxy):
                                if proxy not in self.working_proxies:
                                    self.working_proxies.append(proxy)
                                    
                    tasks = [revalidate_proxy(proxy) for proxy in failed_to_recheck[:20]]
                    await asyncio.gather(*tasks, return_exceptions=True)
                    
            except Exception as e:
                self.logger.error(f"Background validation error: {e}")
                
    async def _background_refresh(self):
        """Background task to refresh proxy pool"""
        while True:
            try:
                await asyncio.sleep(self.refresh_interval)
                
                if len(self.working_proxies) < self.min_pool_size:
                    self.logger.info("Low proxy count, refreshing pool...")
                    await self._refresh_proxy_pool()
                    
            except Exception as e:
                self.logger.error(f"Background refresh error: {e}")
                
    async def get_pool_size(self) -> int:
        """Get current working proxy pool size"""
        return len(self.working_proxies)
        
    async def get_statistics(self) -> Dict[str, Any]:
        """Get proxy pool statistics"""
        total_proxies = len(self.proxy_pool)
        working_proxies = len(self.working_proxies)
        
        country_stats = {}
        protocol_stats = {}
        
        for proxy in self.working_proxies:
            # Country statistics
            country = proxy.country or 'Unknown'
            country_stats[country] = country_stats.get(country, 0) + 1
            
            # Protocol statistics
            protocol = proxy.protocol.value
            protocol_stats[protocol] = protocol_stats.get(protocol, 0) + 1
            
        return {
            'total_proxies': total_proxies,
            'working_proxies': working_proxies,
            'failed_proxies': len(self.failed_proxies),
            'success_rate': (working_proxies / total_proxies * 100) if total_proxies > 0 else 0,
            'country_distribution': country_stats,
            'protocol_distribution': protocol_stats,
            'last_refresh': self.last_refresh
        }
        
    async def health_check(self) -> bool:
        """Check health of proxy manager"""
        try:
            # Check if we have enough working proxies
            if len(self.working_proxies) < self.min_pool_size:
                self.logger.warning(f"Low proxy count: {len(self.working_proxies)} < {self.min_pool_size}")
                return False
                
            # Test getting a proxy
            test_proxy = await self.get_proxy()
            if not test_proxy:
                self.logger.error("Failed to get test proxy")
                return False
                
            self.logger.info(f"Proxy Manager health check passed: {len(self.working_proxies)} working proxies")
            return True
            
        except Exception as e:
            self.logger.error(f"Proxy Manager health check failed: {e}")
            return False
            
    async def stop(self):
        """Stop proxy manager"""
        self.logger.info("Stopping Proxy Manager...")
        # Cancel background tasks if needed
        # Clean up resources

