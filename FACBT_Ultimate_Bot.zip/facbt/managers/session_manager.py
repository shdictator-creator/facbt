"""
Session Manager - Manages bot sessions and account creation tracking
"""

import asyncio
import time
import json
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, asdict
from enum import Enum
from pathlib import Path

from core.account_creator import AccountCreationResult, AccountStatus
from utils.logger import LoggerFactory


@dataclass
class SessionInfo:
    """Session information"""
    session_id: str
    start_time: float
    end_time: Optional[float] = None
    accounts_created: int = 0
    accounts_failed: int = 0
    status: str = "active"
    
    
class SessionManager:
    """Manages bot sessions and tracks progress"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # Session data
        self.current_session: Optional[SessionInfo] = None
        self.session_history: List[SessionInfo] = []
        self.account_results: List[AccountCreationResult] = []
        
        # Configuration
        self.max_concurrent_accounts = config.get('engine', {}).get('max_concurrent_accounts', 3)
        self.session_timeout = config.get('engine', {}).get('session_timeout', 3600)
        
        # Storage
        self.data_dir = Path('data')
        self.data_dir.mkdir(exist_ok=True)
        
    async def start_session(self) -> str:
        """Start a new session"""
        session_id = f"session_{int(time.time())}"
        
        self.current_session = SessionInfo(
            session_id=session_id,
            start_time=time.time()
        )
        
        self.logger.info(f"Started session: {session_id}")
        return session_id
        
    async def end_session(self):
        """End current session"""
        if self.current_session:
            self.current_session.end_time = time.time()
            self.current_session.status = "completed"
            
            # Save to history
            self.session_history.append(self.current_session)
            
            # Save session data
            await self._save_session_data()
            
            self.logger.info(f"Ended session: {self.current_session.session_id}")
            self.current_session = None
            
    async def add_account_result(self, result: AccountCreationResult):
        """Add account creation result"""
        self.account_results.append(result)
        
        if self.current_session:
            if result.success:
                self.current_session.accounts_created += 1
            else:
                self.current_session.accounts_failed += 1
                
    async def get_session_stats(self) -> Dict[str, Any]:
        """Get current session statistics"""
        if not self.current_session:
            return {'error': 'No active session'}
            
        duration = time.time() - self.current_session.start_time
        
        return {
            'session_id': self.current_session.session_id,
            'duration': duration,
            'accounts_created': self.current_session.accounts_created,
            'accounts_failed': self.current_session.accounts_failed,
            'success_rate': (self.current_session.accounts_created / 
                           max(1, self.current_session.accounts_created + self.current_session.accounts_failed)) * 100,
            'status': self.current_session.status
        }
        
    async def _save_session_data(self):
        """Save session data to file"""
        try:
            session_file = self.data_dir / 'sessions.json'
            
            data = {
                'sessions': [asdict(session) for session in self.session_history],
                'accounts': [result.to_dict() for result in self.account_results]
            }
            
            with open(session_file, 'w') as f:
                json.dump(data, f, indent=2, default=str)
                
        except Exception as e:
            self.logger.error(f"Failed to save session data: {e}")
            
    async def health_check(self) -> bool:
        """Check health of session manager"""
        return True

