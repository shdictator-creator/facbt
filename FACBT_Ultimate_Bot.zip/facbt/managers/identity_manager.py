"""
Identity Manager - Generates realistic identities from worldwide countries
"""

import random
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum
import json
from pathlib import Path

try:
    from faker import Faker
    import pycountry
except ImportError:
    print("Installing required packages...")
    import subprocess
    subprocess.check_call(['pip3', 'install', 'faker', 'pycountry'])
    from faker import Faker
    import pycountry

from utils.logger import LoggerFactory


@dataclass
class Identity:
    """Complete identity data structure"""
    first_name: str
    last_name: str
    full_name: str
    email: Optional[str]
    password: str
    birth_date: datetime
    age: int
    gender: str
    country: str
    country_code: str
    city: str
    phone: Optional[str]
    address: Optional[str]
    postal_code: Optional[str]
    nationality: str
    language: str
    timezone: str
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary"""
        return {
            'first_name': self.first_name,
            'last_name': self.last_name,
            'full_name': self.full_name,
            'email': self.email,
            'password': self.password,
            'birth_date': self.birth_date.isoformat(),
            'age': self.age,
            'gender': self.gender,
            'country': self.country,
            'country_code': self.country_code,
            'city': self.city,
            'phone': self.phone,
            'address': self.address,
            'postal_code': self.postal_code,
            'nationality': self.nationality,
            'language': self.language,
            'timezone': self.timezone
        }


class IdentityManager:
    """Manages generation of realistic worldwide identities"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # Identity configuration
        self.identity_config = config.get('identity', {})
        self.cultural_appropriateness = self.identity_config.get('cultural_appropriateness', True)
        self.geographic_consistency = self.identity_config.get('geographic_consistency', True)
        
        # Age distribution
        age_dist = self.identity_config.get('age_distribution', {})
        self.min_age = age_dist.get('min_age', 18)
        self.max_age = age_dist.get('max_age', 65)
        self.preferred_age_range = age_dist.get('preferred_range', [25, 45])
        
        # Gender distribution
        gender_dist = self.identity_config.get('gender_distribution', {})
        self.male_probability = gender_dist.get('male', 0.5)
        
        # Faker instances for different locales
        self.faker_instances = {}
        self.country_data = {}
        
        # Initialize country data
        self._initialize_country_data()
        
    def _initialize_country_data(self):
        """Initialize country data and faker instances"""
        try:
            # Major countries with good Faker support
            self.supported_countries = {
                'US': {'locale': 'en_US', 'timezone': 'America/New_York', 'language': 'en'},
                'CA': {'locale': 'en_CA', 'timezone': 'America/Toronto', 'language': 'en'},
                'GB': {'locale': 'en_GB', 'timezone': 'Europe/London', 'language': 'en'},
                'AU': {'locale': 'en_AU', 'timezone': 'Australia/Sydney', 'language': 'en'},
                'DE': {'locale': 'de_DE', 'timezone': 'Europe/Berlin', 'language': 'de'},
                'FR': {'locale': 'fr_FR', 'timezone': 'Europe/Paris', 'language': 'fr'},
                'ES': {'locale': 'es_ES', 'timezone': 'Europe/Madrid', 'language': 'es'},
                'IT': {'locale': 'it_IT', 'timezone': 'Europe/Rome', 'language': 'it'},
                'NL': {'locale': 'nl_NL', 'timezone': 'Europe/Amsterdam', 'language': 'nl'},
                'BR': {'locale': 'pt_BR', 'timezone': 'America/Sao_Paulo', 'language': 'pt'},
                'MX': {'locale': 'es_MX', 'timezone': 'America/Mexico_City', 'language': 'es'},
                'JP': {'locale': 'ja_JP', 'timezone': 'Asia/Tokyo', 'language': 'ja'},
                'KR': {'locale': 'ko_KR', 'timezone': 'Asia/Seoul', 'language': 'ko'},
                'CN': {'locale': 'zh_CN', 'timezone': 'Asia/Shanghai', 'language': 'zh'},
                'IN': {'locale': 'hi_IN', 'timezone': 'Asia/Kolkata', 'language': 'hi'},
                'RU': {'locale': 'ru_RU', 'timezone': 'Europe/Moscow', 'language': 'ru'},
                'PL': {'locale': 'pl_PL', 'timezone': 'Europe/Warsaw', 'language': 'pl'},
                'TR': {'locale': 'tr_TR', 'timezone': 'Europe/Istanbul', 'language': 'tr'},
                'AR': {'locale': 'es_AR', 'timezone': 'America/Argentina/Buenos_Aires', 'language': 'es'},
                'ZA': {'locale': 'en_ZA', 'timezone': 'Africa/Johannesburg', 'language': 'en'},
                'EG': {'locale': 'ar_EG', 'timezone': 'Africa/Cairo', 'language': 'ar'},
                'NG': {'locale': 'en_NG', 'timezone': 'Africa/Lagos', 'language': 'en'},
                'TH': {'locale': 'th_TH', 'timezone': 'Asia/Bangkok', 'language': 'th'},
                'VN': {'locale': 'vi_VN', 'timezone': 'Asia/Ho_Chi_Minh', 'language': 'vi'},
                'PH': {'locale': 'fil_PH', 'timezone': 'Asia/Manila', 'language': 'fil'},
                'ID': {'locale': 'id_ID', 'timezone': 'Asia/Jakarta', 'language': 'id'},
                'MY': {'locale': 'ms_MY', 'timezone': 'Asia/Kuala_Lumpur', 'language': 'ms'},
                'SG': {'locale': 'en_SG', 'timezone': 'Asia/Singapore', 'language': 'en'},
                'NO': {'locale': 'no_NO', 'timezone': 'Europe/Oslo', 'language': 'no'},
                'SE': {'locale': 'sv_SE', 'timezone': 'Europe/Stockholm', 'language': 'sv'},
                'DK': {'locale': 'da_DK', 'timezone': 'Europe/Copenhagen', 'language': 'da'},
                'FI': {'locale': 'fi_FI', 'timezone': 'Europe/Helsinki', 'language': 'fi'},
                'CH': {'locale': 'de_CH', 'timezone': 'Europe/Zurich', 'language': 'de'},
                'AT': {'locale': 'de_AT', 'timezone': 'Europe/Vienna', 'language': 'de'},
                'BE': {'locale': 'nl_BE', 'timezone': 'Europe/Brussels', 'language': 'nl'},
                'PT': {'locale': 'pt_PT', 'timezone': 'Europe/Lisbon', 'language': 'pt'},
                'GR': {'locale': 'el_GR', 'timezone': 'Europe/Athens', 'language': 'el'},
                'CZ': {'locale': 'cs_CZ', 'timezone': 'Europe/Prague', 'language': 'cs'},
                'HU': {'locale': 'hu_HU', 'timezone': 'Europe/Budapest', 'language': 'hu'},
                'RO': {'locale': 'ro_RO', 'timezone': 'Europe/Bucharest', 'language': 'ro'},
                'BG': {'locale': 'bg_BG', 'timezone': 'Europe/Sofia', 'language': 'bg'},
                'HR': {'locale': 'hr_HR', 'timezone': 'Europe/Zagreb', 'language': 'hr'},
                'SK': {'locale': 'sk_SK', 'timezone': 'Europe/Bratislava', 'language': 'sk'},
                'SI': {'locale': 'sl_SI', 'timezone': 'Europe/Ljubljana', 'language': 'sl'},
                'LT': {'locale': 'lt_LT', 'timezone': 'Europe/Vilnius', 'language': 'lt'},
                'LV': {'locale': 'lv_LV', 'timezone': 'Europe/Riga', 'language': 'lv'},
                'EE': {'locale': 'et_EE', 'timezone': 'Europe/Tallinn', 'language': 'et'},
                'IE': {'locale': 'en_IE', 'timezone': 'Europe/Dublin', 'language': 'en'},
                'IS': {'locale': 'is_IS', 'timezone': 'Atlantic/Reykjavik', 'language': 'is'},
                'NZ': {'locale': 'en_NZ', 'timezone': 'Pacific/Auckland', 'language': 'en'}
            }
            
            # Initialize Faker instances for supported locales
            for country_code, data in self.supported_countries.items():
                try:
                    locale = data['locale']
                    # Fallback to en_US if locale not available
                    try:
                        self.faker_instances[country_code] = Faker(locale)
                    except AttributeError:
                        self.faker_instances[country_code] = Faker('en_US')
                        
                    # Test the faker instance
                    self.faker_instances[country_code].name()
                    
                except Exception as e:
                    self.logger.debug(f"Failed to initialize Faker for {country_code}: {e}")
                    self.faker_instances[country_code] = Faker('en_US')
                    
            # Add country names
            for country_code in self.supported_countries.keys():
                try:
                    country = pycountry.countries.get(alpha_2=country_code)
                    if country:
                        self.supported_countries[country_code]['name'] = country.name
                    else:
                        self.supported_countries[country_code]['name'] = country_code
                except:
                    self.supported_countries[country_code]['name'] = country_code
                    
            self.logger.info(f"Initialized identity data for {len(self.supported_countries)} countries")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize country data: {e}")
            # Fallback to basic setup
            self.supported_countries = {'US': {'locale': 'en_US', 'timezone': 'America/New_York', 'language': 'en', 'name': 'United States'}}
            self.faker_instances = {'US': Faker('en_US')}
            
    async def generate_identity(self, country_code: Optional[str] = None) -> Identity:
        """Generate a realistic identity"""
        try:
            # Select country
            if country_code and country_code in self.supported_countries:
                selected_country = country_code
            else:
                # Weight countries by population/internet usage
                country_weights = {
                    'US': 20, 'CN': 15, 'IN': 12, 'BR': 8, 'JP': 6, 'RU': 5,
                    'DE': 4, 'GB': 4, 'FR': 3, 'IT': 3, 'KR': 3, 'CA': 3,
                    'ES': 2, 'AU': 2, 'MX': 2, 'TR': 2, 'NL': 2, 'PL': 2,
                    'TH': 1, 'VN': 1, 'PH': 1, 'ID': 1, 'MY': 1, 'SG': 1
                }
                
                # Add remaining countries with weight 1
                for cc in self.supported_countries.keys():
                    if cc not in country_weights:
                        country_weights[cc] = 1
                        
                selected_country = self._weighted_choice(country_weights)
                
            country_data = self.supported_countries[selected_country]
            faker = self.faker_instances[selected_country]
            
            # Generate basic info
            gender = 'male' if random.random() < self.male_probability else 'female'
            
            if gender == 'male':
                first_name = faker.first_name_male()
            else:
                first_name = faker.first_name_female()
                
            last_name = faker.last_name()
            full_name = f"{first_name} {last_name}"
            
            # Generate age
            age = self._generate_age()
            birth_date = datetime.now() - timedelta(days=age * 365 + random.randint(0, 365))
            
            # Generate password
            password = self._generate_password()
            
            # Generate location data
            city = faker.city()
            address = faker.address() if random.random() < 0.7 else None
            postal_code = faker.postcode() if random.random() < 0.8 else None
            
            # Generate phone
            phone = faker.phone_number() if random.random() < 0.6 else None
            
            # Create identity
            identity = Identity(
                first_name=first_name,
                last_name=last_name,
                full_name=full_name,
                email=None,  # Will be set by email manager
                password=password,
                birth_date=birth_date,
                age=age,
                gender=gender,
                country=country_data['name'],
                country_code=selected_country,
                city=city,
                phone=phone,
                address=address,
                postal_code=postal_code,
                nationality=country_data['name'],
                language=country_data['language'],
                timezone=country_data['timezone']
            )
            
            self.logger.debug(f"Generated identity: {full_name} from {country_data['name']}")
            return identity
            
        except Exception as e:
            self.logger.error(f"Failed to generate identity: {e}")
            # Return fallback identity
            return await self._generate_fallback_identity()
            
    def _weighted_choice(self, weights: Dict[str, int]) -> str:
        """Select item based on weights"""
        items = list(weights.keys())
        weight_values = list(weights.values())
        total_weight = sum(weight_values)
        
        r = random.uniform(0, total_weight)
        cumulative = 0
        
        for i, weight in enumerate(weight_values):
            cumulative += weight
            if r <= cumulative:
                return items[i]
                
        return items[-1]
        
    def _generate_age(self) -> int:
        """Generate realistic age"""
        # 70% chance of preferred age range
        if random.random() < 0.7:
            return random.randint(self.preferred_age_range[0], self.preferred_age_range[1])
        else:
            return random.randint(self.min_age, self.max_age)
            
    def _generate_password(self) -> str:
        """Generate realistic password"""
        # Common password patterns
        patterns = [
            lambda: f"{random.choice(['password', 'admin', 'user', 'test'])}{random.randint(1, 999)}",
            lambda: f"{random.choice(['Password', 'Admin', 'User'])}{random.randint(1, 99)}!",
            lambda: f"{random.choice(['qwerty', 'abc123', 'password123', '123456789'])}",
            lambda: f"{random.choice(['welcome', 'hello', 'login'])}{random.randint(1, 99)}",
            lambda: f"{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=6))}{random.randint(1, 99)}",
            lambda: f"{''.join(random.choices('ABCDEFGHIJKLMNOPQRSTUVWXYZ', k=2))}{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=4))}{random.randint(1, 99)}"
        ]
        
        return random.choice(patterns)()
        
    async def _generate_fallback_identity(self) -> Identity:
        """Generate fallback identity when main generation fails"""
        faker = Faker('en_US')
        
        gender = 'male' if random.random() < 0.5 else 'female'
        first_name = faker.first_name_male() if gender == 'male' else faker.first_name_female()
        last_name = faker.last_name()
        age = random.randint(18, 65)
        birth_date = datetime.now() - timedelta(days=age * 365)
        
        return Identity(
            first_name=first_name,
            last_name=last_name,
            full_name=f"{first_name} {last_name}",
            email=None,
            password=self._generate_password(),
            birth_date=birth_date,
            age=age,
            gender=gender,
            country="United States",
            country_code="US",
            city=faker.city(),
            phone=None,
            address=None,
            postal_code=None,
            nationality="United States",
            language="en",
            timezone="America/New_York"
        )
        
    async def generate_custom_identity(self, **kwargs) -> Identity:
        """Generate identity with custom parameters"""
        # Start with generated identity
        identity = await self.generate_identity(kwargs.get('country_code'))
        
        # Override with custom values
        for key, value in kwargs.items():
            if hasattr(identity, key) and value is not None:
                setattr(identity, key, value)
                
        # Recalculate derived fields
        if hasattr(identity, 'first_name') and hasattr(identity, 'last_name'):
            identity.full_name = f"{identity.first_name} {identity.last_name}"
            
        return identity
        
    async def get_supported_countries(self) -> List[Dict[str, str]]:
        """Get list of supported countries"""
        countries = []
        for code, data in self.supported_countries.items():
            countries.append({
                'code': code,
                'name': data['name'],
                'language': data['language'],
                'timezone': data['timezone']
            })
        return sorted(countries, key=lambda x: x['name'])
        
    async def get_statistics(self) -> Dict[str, Any]:
        """Get identity generation statistics"""
        return {
            'supported_countries': len(self.supported_countries),
            'faker_instances': len(self.faker_instances),
            'age_range': [self.min_age, self.max_age],
            'preferred_age_range': self.preferred_age_range,
            'cultural_appropriateness': self.cultural_appropriateness,
            'geographic_consistency': self.geographic_consistency
        }
        
    async def health_check(self) -> bool:
        """Check health of identity manager"""
        try:
            # Test identity generation
            test_identity = await self.generate_identity()
            
            if not test_identity or not test_identity.first_name:
                return False
                
            # Test multiple countries
            test_countries = ['US', 'GB', 'DE', 'FR', 'JP']
            for country in test_countries:
                if country in self.supported_countries:
                    test_id = await self.generate_identity(country)
                    if not test_id:
                        return False
                        
            self.logger.info("Identity Manager health check passed")
            return True
            
        except Exception as e:
            self.logger.error(f"Identity Manager health check failed: {e}")
            return False

