"""
User Agent Manager - Manages rotation of 1000+ user agents with intelligent selection
"""

import json
import random
import time
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum
from pathlib import Path

from utils.logger import LoggerFactory


class BrowserType(Enum):
    """Browser types"""
    CHROME = "chrome"
    FIREFOX = "firefox"
    SAFARI = "safari"
    EDGE = "edge"
    OPERA = "opera"


class PlatformType(Enum):
    """Platform types"""
    WINDOWS = "windows"
    MACOS = "macos"
    LINUX = "linux"
    ANDROID = "android"
    IOS = "ios"


@dataclass
class UserAgent:
    """User agent data structure"""
    string: str
    browser: BrowserType
    browser_version: str
    platform: PlatformType
    platform_version: str
    device: Optional[str] = None
    mobile: bool = False
    usage_weight: float = 1.0
    last_used: Optional[float] = None
    
    def __str__(self) -> str:
        return self.string


@dataclass
class BrowserFingerprint:
    """Complete browser fingerprint"""
    user_agent: UserAgent
    screen_resolution: Tuple[int, int]
    viewport_size: Tuple[int, int]
    timezone: str
    language: str
    plugins: List[str]
    webgl_vendor: str
    webgl_renderer: str
    canvas_fingerprint: str
    audio_fingerprint: str


class UserAgentManager:
    """Manages user agent rotation and browser fingerprinting"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # User agent database
        self.user_agents: List[UserAgent] = []
        self.user_agent_index = 0
        self.usage_history: Dict[str, int] = {}
        
        # Browser distributions
        self.browser_distribution = config.get('browser_distribution', {
            'chrome': 0.65,
            'firefox': 0.15,
            'safari': 0.12,
            'edge': 0.08
        })
        
        self.platform_distribution = config.get('platform_distribution', {
            'windows': 0.70,
            'macos': 0.15,
            'linux': 0.10,
            'android': 0.05
        })
        
        # Fingerprint data
        self.screen_resolutions = [
            (1920, 1080), (1366, 768), (1440, 900), (1536, 864),
            (1280, 720), (1600, 900), (2560, 1440), (1920, 1200),
            (1680, 1050), (1280, 1024), (1024, 768), (1152, 864)
        ]
        
        self.timezones = [
            'America/New_York', 'America/Los_Angeles', 'America/Chicago',
            'Europe/London', 'Europe/Paris', 'Europe/Berlin',
            'Asia/Tokyo', 'Asia/Shanghai', 'Asia/Kolkata',
            'Australia/Sydney', 'America/Toronto', 'Europe/Rome'
        ]
        
        self.languages = [
            'en-US', 'en-GB', 'es-ES', 'fr-FR', 'de-DE',
            'it-IT', 'pt-BR', 'ru-RU', 'ja-JP', 'ko-KR',
            'zh-CN', 'ar-SA', 'hi-IN', 'tr-TR', 'pl-PL'
        ]
        
    async def initialize(self):
        """Initialize user agent manager"""
        try:
            self.logger.info("Initializing User Agent Manager...")
            
            # Load user agent database
            await self._load_user_agents()
            
            # Validate database size
            if len(self.user_agents) < 100:
                self.logger.warning(f"Only {len(self.user_agents)} user agents loaded, generating more...")
                await self._generate_additional_user_agents()
                
            self.logger.info(f"User Agent Manager initialized with {len(self.user_agents)} user agents")
            
        except Exception as e:
            self.logger.error(f"Failed to initialize User Agent Manager: {e}")
            raise
            
    async def _load_user_agents(self):
        """Load user agents from database file"""
        try:
            # Try to load from data file
            data_file = Path(__file__).parent.parent / 'data' / 'user_agents.json'
            
            if data_file.exists():
                with open(data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    
                for ua_data in data.get('user_agents', []):
                    user_agent = UserAgent(
                        string=ua_data['string'],
                        browser=BrowserType(ua_data['browser']),
                        browser_version=ua_data['browser_version'],
                        platform=PlatformType(ua_data['platform']),
                        platform_version=ua_data['platform_version'],
                        device=ua_data.get('device'),
                        mobile=ua_data.get('mobile', False),
                        usage_weight=ua_data.get('usage_weight', 1.0)
                    )
                    self.user_agents.append(user_agent)
                    
                self.logger.info(f"Loaded {len(self.user_agents)} user agents from database")
            else:
                # Generate user agents if no database exists
                await self._generate_user_agents_database()
                
        except Exception as e:
            self.logger.warning(f"Failed to load user agent database: {e}")
            await self._generate_user_agents_database()
            
    async def _generate_user_agents_database(self):
        """Generate comprehensive user agent database"""
        self.logger.info("Generating user agent database...")
        
        # Chrome user agents
        chrome_versions = ['119.0.0.0', '118.0.0.0', '117.0.0.0', '116.0.0.0', '115.0.0.0']
        
        # Windows Chrome
        for version in chrome_versions:
            for win_version in ['10.0', '11.0']:
                ua_string = f"Mozilla/5.0 (Windows NT {win_version}; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.CHROME,
                    browser_version=version,
                    platform=PlatformType.WINDOWS,
                    platform_version=win_version,
                    usage_weight=2.0
                ))
                
        # macOS Chrome
        for version in chrome_versions:
            for mac_version in ['10_15_7', '11_0_0', '12_0_0', '13_0_0']:
                ua_string = f"Mozilla/5.0 (Macintosh; Intel Mac OS X {mac_version}) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.CHROME,
                    browser_version=version,
                    platform=PlatformType.MACOS,
                    platform_version=mac_version.replace('_', '.'),
                    usage_weight=1.5
                ))
                
        # Linux Chrome
        for version in chrome_versions:
            ua_string = f"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36"
            self.user_agents.append(UserAgent(
                string=ua_string,
                browser=BrowserType.CHROME,
                browser_version=version,
                platform=PlatformType.LINUX,
                platform_version="x86_64",
                usage_weight=0.8
            ))
            
        # Firefox user agents
        firefox_versions = ['119.0', '118.0', '117.0', '116.0', '115.0']
        
        # Windows Firefox
        for version in firefox_versions:
            for win_version in ['10.0', '11.0']:
                ua_string = f"Mozilla/5.0 (Windows NT {win_version}; Win64; x64; rv:{version}) Gecko/20100101 Firefox/{version}"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.FIREFOX,
                    browser_version=version,
                    platform=PlatformType.WINDOWS,
                    platform_version=win_version,
                    usage_weight=1.2
                ))
                
        # macOS Firefox
        for version in firefox_versions:
            ua_string = f"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15) Gecko/20100101 Firefox/{version}"
            self.user_agents.append(UserAgent(
                string=ua_string,
                browser=BrowserType.FIREFOX,
                browser_version=version,
                platform=PlatformType.MACOS,
                platform_version="10.15",
                usage_weight=1.0
            ))
            
        # Safari user agents
        safari_versions = ['17.0', '16.6', '16.5', '16.4', '16.3']
        
        for version in safari_versions:
            for mac_version in ['10_15_7', '11_0_0', '12_0_0', '13_0_0']:
                ua_string = f"Mozilla/5.0 (Macintosh; Intel Mac OS X {mac_version}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} Safari/605.1.15"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.SAFARI,
                    browser_version=version,
                    platform=PlatformType.MACOS,
                    platform_version=mac_version.replace('_', '.'),
                    usage_weight=1.3
                ))
                
        # Edge user agents
        edge_versions = ['119.0.0.0', '118.0.0.0', '117.0.0.0', '116.0.0.0']
        
        for version in edge_versions:
            for win_version in ['10.0', '11.0']:
                ua_string = f"Mozilla/5.0 (Windows NT {win_version}; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Safari/537.36 Edg/{version}"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.EDGE,
                    browser_version=version,
                    platform=PlatformType.WINDOWS,
                    platform_version=win_version,
                    usage_weight=0.9
                ))
                
        # Mobile user agents
        mobile_chrome_versions = ['119.0.0.0', '118.0.0.0', '117.0.0.0']
        
        # Android Chrome
        for version in mobile_chrome_versions:
            for android_version in ['10', '11', '12', '13', '14']:
                ua_string = f"Mozilla/5.0 (Linux; Android {android_version}; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/{version} Mobile Safari/537.36"
                self.user_agents.append(UserAgent(
                    string=ua_string,
                    browser=BrowserType.CHROME,
                    browser_version=version,
                    platform=PlatformType.ANDROID,
                    platform_version=android_version,
                    device="SM-G973F",
                    mobile=True,
                    usage_weight=0.7
                ))
                
        # iOS Safari
        ios_versions = ['17.0', '16.6', '16.5', '16.4']
        
        for version in ios_versions:
            ua_string = f"Mozilla/5.0 (iPhone; CPU iPhone OS {version.replace('.', '_')} like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/{version} Mobile/15E148 Safari/604.1"
            self.user_agents.append(UserAgent(
                string=ua_string,
                browser=BrowserType.SAFARI,
                browser_version=version,
                platform=PlatformType.IOS,
                platform_version=version,
                device="iPhone",
                mobile=True,
                usage_weight=0.8
            ))
            
        # Generate additional variations
        await self._generate_additional_variations()
        
        # Save to file
        await self._save_user_agents_database()
        
        self.logger.info(f"Generated {len(self.user_agents)} user agents")
        
    async def _generate_additional_variations(self):
        """Generate additional user agent variations"""
        base_count = len(self.user_agents)
        
        # Create variations with different build numbers
        variations = []
        for ua in self.user_agents[:base_count]:
            if ua.browser == BrowserType.CHROME:
                # Vary Chrome build numbers
                for build in ['6533.88', '6533.89', '6533.90']:
                    new_string = ua.string.replace('537.36', build)
                    variations.append(UserAgent(
                        string=new_string,
                        browser=ua.browser,
                        browser_version=ua.browser_version,
                        platform=ua.platform,
                        platform_version=ua.platform_version,
                        device=ua.device,
                        mobile=ua.mobile,
                        usage_weight=ua.usage_weight * 0.8
                    ))
                    
        self.user_agents.extend(variations[:200])  # Add up to 200 variations
        
    async def _generate_additional_user_agents(self):
        """Generate more user agents if needed"""
        target_count = self.config.get('database_size', 1000)
        current_count = len(self.user_agents)
        
        if current_count >= target_count:
            return
            
        needed = target_count - current_count
        self.logger.info(f"Generating {needed} additional user agents...")
        
        # Generate random variations
        for _ in range(needed):
            base_ua = random.choice(self.user_agents)
            
            # Create variation
            new_ua = self._create_user_agent_variation(base_ua)
            self.user_agents.append(new_ua)
            
    def _create_user_agent_variation(self, base_ua: UserAgent) -> UserAgent:
        """Create a variation of an existing user agent"""
        # Slightly modify version numbers
        if base_ua.browser == BrowserType.CHROME:
            version_parts = base_ua.browser_version.split('.')
            if len(version_parts) >= 3:
                # Vary patch version
                patch = int(version_parts[2]) + random.randint(-2, 2)
                patch = max(0, patch)
                version_parts[2] = str(patch)
                new_version = '.'.join(version_parts)
                
                new_string = base_ua.string.replace(base_ua.browser_version, new_version)
                
                return UserAgent(
                    string=new_string,
                    browser=base_ua.browser,
                    browser_version=new_version,
                    platform=base_ua.platform,
                    platform_version=base_ua.platform_version,
                    device=base_ua.device,
                    mobile=base_ua.mobile,
                    usage_weight=base_ua.usage_weight * 0.9
                )
                
        return base_ua
        
    async def _save_user_agents_database(self):
        """Save user agents database to file"""
        try:
            data_dir = Path(__file__).parent.parent / 'data'
            data_dir.mkdir(exist_ok=True)
            
            data_file = data_dir / 'user_agents.json'
            
            data = {
                'generated_at': time.time(),
                'count': len(self.user_agents),
                'user_agents': [
                    {
                        'string': ua.string,
                        'browser': ua.browser.value,
                        'browser_version': ua.browser_version,
                        'platform': ua.platform.value,
                        'platform_version': ua.platform_version,
                        'device': ua.device,
                        'mobile': ua.mobile,
                        'usage_weight': ua.usage_weight
                    }
                    for ua in self.user_agents
                ]
            }
            
            with open(data_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
                
            self.logger.info(f"Saved user agents database to {data_file}")
            
        except Exception as e:
            self.logger.warning(f"Failed to save user agents database: {e}")
            
    async def get_user_agent(self, browser: Optional[BrowserType] = None,
                           platform: Optional[PlatformType] = None,
                           mobile: Optional[bool] = None) -> UserAgent:
        """Get a user agent based on criteria"""
        try:
            # Filter user agents based on criteria
            candidates = self.user_agents
            
            if browser:
                candidates = [ua for ua in candidates if ua.browser == browser]
            if platform:
                candidates = [ua for ua in candidates if ua.platform == platform]
            if mobile is not None:
                candidates = [ua for ua in candidates if ua.mobile == mobile]
                
            if not candidates:
                # Fallback to any user agent
                candidates = self.user_agents
                
            # Select based on strategy
            strategy = self.config.get('rotation_strategy', 'weighted_random')
            
            if strategy == 'round_robin':
                user_agent = self._select_round_robin(candidates)
            elif strategy == 'random':
                user_agent = random.choice(candidates)
            elif strategy == 'weighted_random':
                user_agent = self._select_weighted_random(candidates)
            else:
                user_agent = random.choice(candidates)
                
            # Update usage tracking
            user_agent.last_used = time.time()
            self.usage_history[user_agent.string] = self.usage_history.get(user_agent.string, 0) + 1
            
            self.logger.debug(f"Selected user agent: {user_agent.browser.value} {user_agent.browser_version} on {user_agent.platform.value}")
            
            return user_agent
            
        except Exception as e:
            self.logger.error(f"Failed to get user agent: {e}")
            # Return a default user agent
            return self._get_default_user_agent()
            
    def _select_round_robin(self, candidates: List[UserAgent]) -> UserAgent:
        """Select user agent using round-robin strategy"""
        if not candidates:
            return self._get_default_user_agent()
            
        user_agent = candidates[self.user_agent_index % len(candidates)]
        self.user_agent_index += 1
        
        return user_agent
        
    def _select_weighted_random(self, candidates: List[UserAgent]) -> UserAgent:
        """Select user agent using weighted random strategy"""
        if not candidates:
            return self._get_default_user_agent()
            
        # Calculate weights
        weights = [ua.usage_weight for ua in candidates]
        total_weight = sum(weights)
        
        if total_weight == 0:
            return random.choice(candidates)
            
        # Weighted random selection
        r = random.uniform(0, total_weight)
        cumulative = 0
        
        for i, weight in enumerate(weights):
            cumulative += weight
            if r <= cumulative:
                return candidates[i]
                
        return candidates[-1]
        
    def _get_default_user_agent(self) -> UserAgent:
        """Get a default user agent as fallback"""
        return UserAgent(
            string="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36",
            browser=BrowserType.CHROME,
            browser_version="119.0.0.0",
            platform=PlatformType.WINDOWS,
            platform_version="10.0",
            usage_weight=1.0
        )
        
    async def get_browser_fingerprint(self, user_agent: Optional[UserAgent] = None) -> BrowserFingerprint:
        """Get a complete browser fingerprint"""
        if not user_agent:
            user_agent = await self.get_user_agent()
            
        # Select appropriate screen resolution based on platform
        if user_agent.mobile:
            mobile_resolutions = [(360, 640), (375, 667), (414, 896), (390, 844)]
            screen_resolution = random.choice(mobile_resolutions)
            viewport_size = (screen_resolution[0], screen_resolution[1] - 100)
        else:
            screen_resolution = random.choice(self.screen_resolutions)
            viewport_size = (screen_resolution[0] - 20, screen_resolution[1] - 100)
            
        # Select timezone and language
        timezone = random.choice(self.timezones)
        language = random.choice(self.languages)
        
        # Generate plugins based on browser
        plugins = self._generate_plugins(user_agent)
        
        # Generate WebGL info
        webgl_vendor, webgl_renderer = self._generate_webgl_info(user_agent)
        
        # Generate fingerprints
        canvas_fingerprint = self._generate_canvas_fingerprint()
        audio_fingerprint = self._generate_audio_fingerprint()
        
        return BrowserFingerprint(
            user_agent=user_agent,
            screen_resolution=screen_resolution,
            viewport_size=viewport_size,
            timezone=timezone,
            language=language,
            plugins=plugins,
            webgl_vendor=webgl_vendor,
            webgl_renderer=webgl_renderer,
            canvas_fingerprint=canvas_fingerprint,
            audio_fingerprint=audio_fingerprint
        )
        
    def _generate_plugins(self, user_agent: UserAgent) -> List[str]:
        """Generate realistic plugins list"""
        base_plugins = [
            "PDF Viewer",
            "Chrome PDF Viewer",
            "Chromium PDF Viewer",
            "Microsoft Edge PDF Viewer",
            "WebKit built-in PDF"
        ]
        
        if user_agent.platform == PlatformType.WINDOWS:
            base_plugins.extend([
                "Adobe Acrobat",
                "Microsoft Silverlight",
                "Windows Media Player"
            ])
        elif user_agent.platform == PlatformType.MACOS:
            base_plugins.extend([
                "QuickTime Plug-in",
                "Safari PDF plug-in"
            ])
            
        # Randomly select subset
        num_plugins = random.randint(2, min(6, len(base_plugins)))
        return random.sample(base_plugins, num_plugins)
        
    def _generate_webgl_info(self, user_agent: UserAgent) -> Tuple[str, str]:
        """Generate WebGL vendor and renderer info"""
        if user_agent.platform == PlatformType.WINDOWS:
            vendors = ["Google Inc.", "Microsoft Corporation", "Intel Inc."]
            renderers = [
                "ANGLE (Intel(R) HD Graphics 620 Direct3D11 vs_5_0 ps_5_0)",
                "ANGLE (NVIDIA GeForce GTX 1060 Direct3D11 vs_5_0 ps_5_0)",
                "ANGLE (AMD Radeon RX 580 Direct3D11 vs_5_0 ps_5_0)"
            ]
        elif user_agent.platform == PlatformType.MACOS:
            vendors = ["Apple Inc.", "Intel Inc."]
            renderers = [
                "Apple GPU",
                "Intel Iris Pro OpenGL Engine",
                "AMD Radeon Pro 560X OpenGL Engine"
            ]
        else:
            vendors = ["Mesa", "Intel Inc."]
            renderers = [
                "Mesa DRI Intel(R) HD Graphics",
                "Mesa DRI AMD Radeon",
                "llvmpipe (LLVM 12.0.0, 256 bits)"
            ]
            
        return random.choice(vendors), random.choice(renderers)
        
    def _generate_canvas_fingerprint(self) -> str:
        """Generate canvas fingerprint"""
        # Simulate canvas fingerprint hash
        import hashlib
        data = f"{random.randint(1000000, 9999999)}{time.time()}"
        return hashlib.md5(data.encode()).hexdigest()[:16]
        
    def _generate_audio_fingerprint(self) -> str:
        """Generate audio fingerprint"""
        # Simulate audio fingerprint hash
        import hashlib
        data = f"{random.randint(1000000, 9999999)}{time.time()}"
        return hashlib.sha256(data.encode()).hexdigest()[:32]
        
    async def get_statistics(self) -> Dict[str, Any]:
        """Get user agent usage statistics"""
        total_usage = sum(self.usage_history.values())
        
        browser_stats = {}
        platform_stats = {}
        
        for ua in self.user_agents:
            usage_count = self.usage_history.get(ua.string, 0)
            
            # Browser statistics
            browser_key = ua.browser.value
            if browser_key not in browser_stats:
                browser_stats[browser_key] = {'count': 0, 'usage': 0}
            browser_stats[browser_key]['count'] += 1
            browser_stats[browser_key]['usage'] += usage_count
            
            # Platform statistics
            platform_key = ua.platform.value
            if platform_key not in platform_stats:
                platform_stats[platform_key] = {'count': 0, 'usage': 0}
            platform_stats[platform_key]['count'] += 1
            platform_stats[platform_key]['usage'] += usage_count
            
        return {
            'total_user_agents': len(self.user_agents),
            'total_usage': total_usage,
            'browser_distribution': browser_stats,
            'platform_distribution': platform_stats,
            'most_used': max(self.usage_history.items(), key=lambda x: x[1]) if self.usage_history else None
        }
        
    async def health_check(self) -> bool:
        """Check health of user agent manager"""
        try:
            # Check if we have enough user agents
            min_required = 100
            if len(self.user_agents) < min_required:
                self.logger.warning(f"Low user agent count: {len(self.user_agents)} < {min_required}")
                return False
                
            # Check if we can get a user agent
            test_ua = await self.get_user_agent()
            if not test_ua or not test_ua.string:
                self.logger.error("Failed to get test user agent")
                return False
                
            self.logger.info(f"User Agent Manager health check passed: {len(self.user_agents)} user agents available")
            return True
            
        except Exception as e:
            self.logger.error(f"User Agent Manager health check failed: {e}")
            return False

