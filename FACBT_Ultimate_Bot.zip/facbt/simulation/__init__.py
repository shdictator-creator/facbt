"""
Simulation Module - Human behavior and anti-detection systems
"""

from .human_behavior import HumanBehaviorSimulator, BehaviorProfile, TypingPattern, MousePattern
from .anti_detection import AntiDetectionSystem, DetectionAvoidance

__all__ = [
    'HumanBehaviorSimulator',
    'BehaviorProfile', 
    'TypingPattern',
    'MousePattern',
    'AntiDetectionSystem',
    'DetectionAvoidance'
]

