"""
Human Behavior Simulation - Mimics realistic human interaction patterns
"""

import asyncio
import random
import time
import math
from typing import Dict, List, Optional, Any, Tuple
from dataclasses import dataclass
from enum import Enum

from utils.logger import LoggerFactory


class InteractionType(Enum):
    """Types of user interactions"""
    TYPING = "typing"
    MOUSE_MOVEMENT = "mouse_movement"
    CLICKING = "clicking"
    SCROLLING = "scrolling"
    READING = "reading"
    THINKING = "thinking"


@dataclass
class TypingPattern:
    """Typing behavior pattern"""
    wpm: int
    error_rate: float
    correction_probability: float
    pause_probability: float
    burst_typing: bool
    
    
@dataclass
class MousePattern:
    """Mouse movement pattern"""
    speed: str  # slow, normal, fast
    acceleration_curve: str  # linear, human, smooth
    precision: float
    hover_probability: float
    
    
@dataclass
class BehaviorProfile:
    """Complete human behavior profile"""
    typing: TypingPattern
    mouse: MousePattern
    attention_span: Tuple[int, int]  # min, max seconds
    fatigue_factor: float
    circadian_active: bool


class HumanBehaviorSimulator:
    """Simulates realistic human behavior patterns"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        
        # Behavior configuration
        self.typing_config = config.get('typing', {})
        self.mouse_config = config.get('mouse', {})
        self.timing_config = config.get('timing', {})
        self.interaction_config = config.get('interaction', {})
        
        # Current session state
        self.session_start_time = time.time()
        self.total_interactions = 0
        self.current_fatigue = 0.0
        self.last_interaction_time = 0.0
        
        # Behavior profiles
        self.behavior_profiles = self._generate_behavior_profiles()
        self.current_profile = random.choice(self.behavior_profiles)
        
    def _generate_behavior_profiles(self) -> List[BehaviorProfile]:
        """Generate diverse human behavior profiles"""
        profiles = []
        
        # Fast typist profile
        profiles.append(BehaviorProfile(
            typing=TypingPattern(
                wpm=random.randint(60, 80),
                error_rate=0.01,
                correction_probability=0.9,
                pause_probability=0.05,
                burst_typing=True
            ),
            mouse=MousePattern(
                speed="fast",
                acceleration_curve="human",
                precision=0.95,
                hover_probability=0.2
            ),
            attention_span=(600, 1800),
            fatigue_factor=0.05,
            circadian_active=True
        ))
        
        # Average user profile
        profiles.append(BehaviorProfile(
            typing=TypingPattern(
                wpm=random.randint(35, 50),
                error_rate=0.03,
                correction_probability=0.8,
                pause_probability=0.15,
                burst_typing=False
            ),
            mouse=MousePattern(
                speed="normal",
                acceleration_curve="human",
                precision=0.85,
                hover_probability=0.4
            ),
            attention_span=(300, 1200),
            fatigue_factor=0.1,
            circadian_active=True
        ))
        
        # Careful user profile
        profiles.append(BehaviorProfile(
            typing=TypingPattern(
                wpm=random.randint(20, 35),
                error_rate=0.02,
                correction_probability=0.95,
                pause_probability=0.25,
                burst_typing=False
            ),
            mouse=MousePattern(
                speed="slow",
                acceleration_curve="smooth",
                precision=0.98,
                hover_probability=0.6
            ),
            attention_span=(180, 900),
            fatigue_factor=0.15,
            circadian_active=False
        ))
        
        # Mobile user profile
        profiles.append(BehaviorProfile(
            typing=TypingPattern(
                wpm=random.randint(25, 40),
                error_rate=0.05,
                correction_probability=0.7,
                pause_probability=0.2,
                burst_typing=False
            ),
            mouse=MousePattern(
                speed="normal",
                acceleration_curve="human",
                precision=0.8,
                hover_probability=0.1
            ),
            attention_span=(120, 600),
            fatigue_factor=0.2,
            circadian_active=True
        ))
        
        return profiles
        
    async def simulate_typing(self, text: str, element_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Simulate human-like typing behavior"""
        actions = []
        
        if not text:
            return actions
            
        # Calculate typing parameters
        wpm = self.current_profile.typing.wpm
        chars_per_second = (wpm * 5) / 60  # Average 5 chars per word
        base_delay = 1.0 / chars_per_second
        
        # Add initial thinking delay
        thinking_delay = await self._calculate_thinking_delay(len(text))
        if thinking_delay > 0:
            actions.append({
                'type': 'delay',
                'duration': thinking_delay,
                'reason': 'thinking'
            })
            
        current_text = ""
        i = 0
        
        while i < len(text):
            char = text[i]
            
            # Simulate typing errors
            if random.random() < self.current_profile.typing.error_rate:
                # Type wrong character
                wrong_char = random.choice('abcdefghijklmnopqrstuvwxyz')
                current_text += wrong_char
                
                actions.append({
                    'type': 'type_char',
                    'char': wrong_char,
                    'element_id': element_id,
                    'current_text': current_text
                })
                
                # Delay before correction
                await asyncio.sleep(random.uniform(0.1, 0.3))
                
                # Correct the error if probability allows
                if random.random() < self.current_profile.typing.correction_probability:
                    # Backspace
                    current_text = current_text[:-1]
                    actions.append({
                        'type': 'backspace',
                        'element_id': element_id,
                        'current_text': current_text
                    })
                    
                    await asyncio.sleep(random.uniform(0.05, 0.15))
                else:
                    # Skip the correct character since we typed wrong
                    i += 1
                    continue
                    
            # Type the correct character
            current_text += char
            actions.append({
                'type': 'type_char',
                'char': char,
                'element_id': element_id,
                'current_text': current_text
            })
            
            # Calculate delay for next character
            delay = self._calculate_typing_delay(char, base_delay)
            
            # Add random pauses
            if random.random() < self.current_profile.typing.pause_probability:
                delay += random.uniform(0.5, 2.0)
                actions.append({
                    'type': 'delay',
                    'duration': delay,
                    'reason': 'natural_pause'
                })
            else:
                await asyncio.sleep(delay)
                
            i += 1
            
        return actions
        
    def _calculate_typing_delay(self, char: str, base_delay: float) -> float:
        """Calculate realistic typing delay for a character"""
        delay = base_delay
        
        # Adjust for character complexity
        if char.isupper():
            delay *= 1.2  # Shift key
        elif char in '!@#$%^&*()_+{}|:"<>?':
            delay *= 1.5  # Special characters
        elif char in '1234567890':
            delay *= 1.1  # Numbers
        elif char == ' ':
            delay *= 0.8  # Space is faster
            
        # Add natural variation
        delay *= random.uniform(0.7, 1.3)
        
        # Burst typing effect
        if self.current_profile.typing.burst_typing and random.random() < 0.3:
            delay *= 0.6
            
        return max(0.05, delay)
        
    async def _calculate_thinking_delay(self, text_length: int) -> float:
        """Calculate thinking delay before typing"""
        base_delay = text_length * 0.1  # Base thinking time
        
        # Adjust for complexity
        if text_length > 50:
            base_delay *= 1.5
        elif text_length < 10:
            base_delay *= 0.5
            
        # Add randomness
        delay = random.uniform(base_delay * 0.5, base_delay * 1.5)
        
        # Cap the delay
        return min(delay, 5.0)
        
    async def simulate_mouse_movement(self, start_pos: Tuple[int, int], 
                                    end_pos: Tuple[int, int]) -> List[Dict[str, Any]]:
        """Simulate human-like mouse movement"""
        actions = []
        
        if start_pos == end_pos:
            return actions
            
        # Calculate movement parameters
        distance = math.sqrt((end_pos[0] - start_pos[0])**2 + (end_pos[1] - start_pos[1])**2)
        
        # Determine movement style
        if self.current_profile.mouse.speed == "fast":
            steps = max(5, int(distance / 20))
            base_delay = 0.01
        elif self.current_profile.mouse.speed == "slow":
            steps = max(10, int(distance / 10))
            base_delay = 0.05
        else:  # normal
            steps = max(8, int(distance / 15))
            base_delay = 0.02
            
        # Generate movement path
        path_points = self._generate_mouse_path(start_pos, end_pos, steps)
        
        for i, point in enumerate(path_points):
            actions.append({
                'type': 'mouse_move',
                'position': point,
                'step': i,
                'total_steps': len(path_points)
            })
            
            # Calculate delay
            delay = base_delay * random.uniform(0.8, 1.2)
            
            # Add acceleration curve
            if self.current_profile.mouse.acceleration_curve == "human":
                # Slower at start and end, faster in middle
                progress = i / len(path_points)
                if progress < 0.3:
                    delay *= 1.5
                elif progress > 0.7:
                    delay *= 1.3
                else:
                    delay *= 0.8
                    
            await asyncio.sleep(delay)
            
        return actions
        
    def _generate_mouse_path(self, start: Tuple[int, int], end: Tuple[int, int], 
                           steps: int) -> List[Tuple[int, int]]:
        """Generate realistic mouse movement path"""
        path = []
        
        # Add slight curve to movement
        control_point = (
            (start[0] + end[0]) / 2 + random.randint(-20, 20),
            (start[1] + end[1]) / 2 + random.randint(-20, 20)
        )
        
        for i in range(steps + 1):
            t = i / steps
            
            # Quadratic Bezier curve
            x = (1-t)**2 * start[0] + 2*(1-t)*t * control_point[0] + t**2 * end[0]
            y = (1-t)**2 * start[1] + 2*(1-t)*t * control_point[1] + t**2 * end[1]
            
            # Add small random variations
            x += random.randint(-2, 2)
            y += random.randint(-2, 2)
            
            path.append((int(x), int(y)))
            
        return path
        
    async def simulate_click(self, position: Tuple[int, int], 
                           click_type: str = "left") -> List[Dict[str, Any]]:
        """Simulate human-like clicking"""
        actions = []
        
        # Pre-click hover
        if random.random() < self.current_profile.mouse.hover_probability:
            hover_duration = random.uniform(0.2, 1.0)
            actions.append({
                'type': 'hover',
                'position': position,
                'duration': hover_duration
            })
            await asyncio.sleep(hover_duration)
            
        # Click timing
        press_duration = random.uniform(0.08, 0.15)
        
        actions.append({
            'type': 'mouse_down',
            'position': position,
            'button': click_type
        })
        
        await asyncio.sleep(press_duration)
        
        actions.append({
            'type': 'mouse_up',
            'position': position,
            'button': click_type
        })
        
        # Post-click delay
        post_delay = random.uniform(0.1, 0.3)
        await asyncio.sleep(post_delay)
        
        return actions
        
    async def simulate_reading(self, text_length: int) -> float:
        """Simulate reading time for text"""
        # Average reading speed: 200-250 WPM
        reading_speed = self.timing_config.get('reading_speed_wpm', 200)
        
        # Estimate word count (average 5 chars per word)
        word_count = text_length / 5
        
        # Calculate reading time
        reading_time = (word_count / reading_speed) * 60
        
        # Add variation
        reading_time *= random.uniform(0.8, 1.5)
        
        # Minimum reading time
        reading_time = max(1.0, reading_time)
        
        return reading_time
        
    async def simulate_form_interaction(self, form_fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Simulate realistic form filling behavior"""
        actions = []
        
        # Initial form assessment (reading)
        assessment_time = await self.simulate_reading(sum(len(field.get('label', '')) for field in form_fields))
        actions.append({
            'type': 'delay',
            'duration': assessment_time,
            'reason': 'form_assessment'
        })
        
        for i, field in enumerate(form_fields):
            field_type = field.get('type', 'text')
            field_value = field.get('value', '')
            
            # Focus on field
            actions.append({
                'type': 'focus_field',
                'field_id': field.get('id'),
                'field_type': field_type
            })
            
            # Thinking delay before typing
            thinking_time = await self._calculate_thinking_delay(len(field_value))
            if thinking_time > 0:
                actions.append({
                    'type': 'delay',
                    'duration': thinking_time,
                    'reason': 'field_thinking'
                })
                
            # Type the value
            if field_value:
                typing_actions = await self.simulate_typing(field_value, field.get('id'))
                actions.extend(typing_actions)
                
            # Validation delay (user checking their input)
            if field_type in ['email', 'password', 'phone']:
                validation_delay = random.uniform(1.0, 3.0)
                actions.append({
                    'type': 'delay',
                    'duration': validation_delay,
                    'reason': 'field_validation'
                })
                
            # Tab to next field or random click
            if i < len(form_fields) - 1:
                if random.random() < 0.7:
                    actions.append({
                        'type': 'key_press',
                        'key': 'Tab'
                    })
                else:
                    # Click on next field
                    next_field = form_fields[i + 1]
                    actions.append({
                        'type': 'click_field',
                        'field_id': next_field.get('id')
                    })
                    
        return actions
        
    async def simulate_page_interaction(self, page_type: str = "form") -> List[Dict[str, Any]]:
        """Simulate general page interaction patterns"""
        actions = []
        
        # Initial page load assessment
        load_assessment = random.uniform(2.0, 5.0)
        actions.append({
            'type': 'delay',
            'duration': load_assessment,
            'reason': 'page_assessment'
        })
        
        # Scroll behavior
        if random.random() < self.interaction_config.get('scroll_probability', 0.7):
            scroll_actions = await self._simulate_scrolling()
            actions.extend(scroll_actions)
            
        # Random interactions based on page type
        if page_type == "registration":
            # More careful behavior on registration pages
            actions.extend(await self._simulate_registration_behavior())
        elif page_type == "form":
            actions.extend(await self._simulate_form_behavior())
            
        return actions
        
    async def _simulate_scrolling(self) -> List[Dict[str, Any]]:
        """Simulate realistic scrolling behavior"""
        actions = []
        
        scroll_count = random.randint(1, 3)
        
        for _ in range(scroll_count):
            # Scroll direction and amount
            direction = random.choice(['down', 'up'])
            amount = random.randint(100, 300)
            
            actions.append({
                'type': 'scroll',
                'direction': direction,
                'amount': amount
            })
            
            # Pause to read
            read_time = random.uniform(1.0, 3.0)
            actions.append({
                'type': 'delay',
                'duration': read_time,
                'reason': 'reading_content'
            })
            
        return actions
        
    async def _simulate_registration_behavior(self) -> List[Dict[str, Any]]:
        """Simulate behavior specific to registration pages"""
        actions = []
        
        # Users often read terms/privacy policy
        if random.random() < 0.3:
            actions.append({
                'type': 'delay',
                'duration': random.uniform(5.0, 15.0),
                'reason': 'reading_terms'
            })
            
        # Double-check email field
        if random.random() < 0.4:
            actions.append({
                'type': 'delay',
                'duration': random.uniform(2.0, 4.0),
                'reason': 'email_verification'
            })
            
        return actions
        
    async def _simulate_form_behavior(self) -> List[Dict[str, Any]]:
        """Simulate general form interaction behavior"""
        actions = []
        
        # Form validation checking
        if random.random() < 0.5:
            actions.append({
                'type': 'delay',
                'duration': random.uniform(1.0, 3.0),
                'reason': 'form_validation'
            })
            
        return actions
        
    def update_fatigue(self):
        """Update user fatigue based on session duration"""
        session_duration = time.time() - self.session_start_time
        self.current_fatigue = min(1.0, session_duration / 3600 * self.current_profile.fatigue_factor)
        
    def should_take_break(self) -> bool:
        """Determine if user should take a break"""
        self.update_fatigue()
        
        # Check attention span
        session_duration = time.time() - self.session_start_time
        min_attention, max_attention = self.current_profile.attention_span
        
        if session_duration > max_attention:
            return True
            
        # Fatigue-based break probability
        if self.current_fatigue > 0.7 and random.random() < 0.3:
            return True
            
        return False
        
    async def take_break(self) -> Dict[str, Any]:
        """Simulate taking a break"""
        break_duration = random.uniform(30, 300)  # 30 seconds to 5 minutes
        
        self.logger.info(f"Taking break for {break_duration:.1f} seconds")
        
        return {
            'type': 'break',
            'duration': break_duration,
            'reason': 'fatigue' if self.current_fatigue > 0.5 else 'attention_span'
        }
        
    def get_current_behavior_stats(self) -> Dict[str, Any]:
        """Get current behavior statistics"""
        return {
            'profile_type': f"Profile_{self.behavior_profiles.index(self.current_profile)}",
            'typing_wpm': self.current_profile.typing.wpm,
            'mouse_speed': self.current_profile.mouse.speed,
            'session_duration': time.time() - self.session_start_time,
            'total_interactions': self.total_interactions,
            'current_fatigue': self.current_fatigue,
            'attention_span': self.current_profile.attention_span
        }
        
    async def health_check(self) -> bool:
        """Check health of behavior simulator"""
        try:
            # Test basic functionality
            test_actions = await self.simulate_typing("test")
            if not test_actions:
                return False
                
            self.logger.info("Human Behavior Simulator health check passed")
            return True
            
        except Exception as e:
            self.logger.error(f"Human Behavior Simulator health check failed: {e}")
            return False

