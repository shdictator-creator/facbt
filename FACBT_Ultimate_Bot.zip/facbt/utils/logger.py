"""
FACBT Logger - Structured logging system with sensitive data filtering
"""

import logging
import json
import os
import sys
import re
from datetime import datetime
from typing import Any, Dict, Optional
from pathlib import Path


class SensitiveDataFilter:
    """Filter sensitive data from log messages"""
    
    def __init__(self):
        # Patterns for sensitive data
        self.patterns = [
            (r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b', '[EMAIL]'),  # Email
            (r'\b\d{4,6}\b', '[CODE]'),  # Verification codes
            (r'password["\']?\s*[:=]\s*["\']?([^"\'\\s]+)', 'password: [PASSWORD]'),  # Passwords
            (r'token["\']?\s*[:=]\s*["\']?([^"\'\\s]+)', 'token: [TOKEN]'),  # Tokens
            (r'key["\']?\s*[:=]\s*["\']?([^"\'\\s]+)', 'key: [KEY]'),  # API keys
        ]
        
    def filter_message(self, message: str) -> str:
        """Filter sensitive data from message"""
        filtered = message
        for pattern, replacement in self.patterns:
            filtered = re.sub(pattern, replacement, filtered, flags=re.IGNORECASE)
        return filtered


class JSONFormatter(logging.Formatter):
    """JSON formatter for structured logging"""
    
    def __init__(self, include_caller: bool = True, include_thread: bool = True):
        super().__init__()
        self.include_caller = include_caller
        self.include_thread = include_thread
        self.sensitive_filter = SensitiveDataFilter()
        
    def format(self, record: logging.LogRecord) -> str:
        """Format log record as JSON"""
        log_entry = {
            'timestamp': datetime.fromtimestamp(record.created).isoformat(),
            'level': record.levelname,
            'logger': record.name,
            'message': self.sensitive_filter.filter_message(record.getMessage()),
        }
        
        # Add caller information
        if self.include_caller and hasattr(record, 'pathname'):
            log_entry['caller'] = {
                'file': os.path.basename(record.pathname),
                'function': record.funcName,
                'line': record.lineno
            }
            
        # Add thread information
        if self.include_thread:
            log_entry['thread'] = {
                'id': record.thread,
                'name': record.threadName
            }
            
        # Add extra fields
        if hasattr(record, 'extra_fields'):
            log_entry.update(record.extra_fields)
            
        # Add exception information
        if record.exc_info:
            log_entry['exception'] = self.formatException(record.exc_info)
            
        return json.dumps(log_entry, ensure_ascii=False)


class ColoredConsoleFormatter(logging.Formatter):
    """Colored console formatter for better readability"""
    
    COLORS = {
        'DEBUG': '\033[36m',     # Cyan
        'INFO': '\033[32m',      # Green
        'WARNING': '\033[33m',   # Yellow
        'ERROR': '\033[31m',     # Red
        'CRITICAL': '\033[35m',  # Magenta
    }
    RESET = '\033[0m'
    
    def __init__(self, colored: bool = True):
        super().__init__()
        self.colored = colored and sys.stdout.isatty()
        self.sensitive_filter = SensitiveDataFilter()
        
    def format(self, record: logging.LogRecord) -> str:
        """Format log record with colors"""
        timestamp = datetime.fromtimestamp(record.created).strftime('%H:%M:%S')
        level = record.levelname
        logger_name = record.name.split('.')[-1]  # Use only the last part
        message = self.sensitive_filter.filter_message(record.getMessage())
        
        if self.colored:
            color = self.COLORS.get(level, '')
            formatted = f"{color}[{timestamp}] {level:8} {logger_name:15} | {message}{self.RESET}"
        else:
            formatted = f"[{timestamp}] {level:8} {logger_name:15} | {message}"
            
        return formatted


class PerformanceLogger:
    """Logger for performance metrics and timing"""
    
    def __init__(self, logger: logging.Logger):
        self.logger = logger
        
    def log_timing(self, operation: str, duration: float, **kwargs):
        """Log operation timing"""
        self.logger.info(
            f"Performance: {operation} completed in {duration:.3f}s",
            extra={'extra_fields': {
                'performance': {
                    'operation': operation,
                    'duration_seconds': duration,
                    **kwargs
                }
            }}
        )
        
    def log_counter(self, metric: str, value: int, **kwargs):
        """Log counter metric"""
        self.logger.info(
            f"Metric: {metric} = {value}",
            extra={'extra_fields': {
                'metric': {
                    'name': metric,
                    'value': value,
                    'type': 'counter',
                    **kwargs
                }
            }}
        )
        
    def log_gauge(self, metric: str, value: float, **kwargs):
        """Log gauge metric"""
        self.logger.info(
            f"Metric: {metric} = {value}",
            extra={'extra_fields': {
                'metric': {
                    'name': metric,
                    'value': value,
                    'type': 'gauge',
                    **kwargs
                }
            }}
        )


class LoggerFactory:
    """Factory for creating configured loggers"""
    
    _configured = False
    _config = {}
    
    @classmethod
    def configure(cls, config: Dict[str, Any]):
        """Configure logging system"""
        cls._config = config
        cls._setup_logging()
        cls._configured = True
        
    @classmethod
    def _setup_logging(cls):
        """Setup logging configuration"""
        config = cls._config
        
        # Get log level
        log_level = config.get('level', 'INFO').upper()
        numeric_level = getattr(logging, log_level, logging.INFO)
        
        # Clear existing handlers
        root_logger = logging.getLogger()
        root_logger.handlers.clear()
        
        # Set root level
        root_logger.setLevel(numeric_level)
        
        # Setup outputs
        outputs = config.get('outputs', {})
        
        # Console output
        console_config = outputs.get('console', {})
        if console_config.get('enabled', True):
            console_handler = logging.StreamHandler(sys.stdout)
            console_level = console_config.get('level', log_level)
            console_handler.setLevel(getattr(logging, console_level, numeric_level))
            
            if console_config.get('colored', True):
                console_handler.setFormatter(ColoredConsoleFormatter())
            else:
                console_handler.setFormatter(ColoredConsoleFormatter(colored=False))
                
            root_logger.addHandler(console_handler)
            
        # File output
        file_config = outputs.get('file', {})
        if file_config.get('enabled', False):
            log_file = file_config.get('path', 'logs/facbt.log')
            
            # Create log directory
            Path(log_file).parent.mkdir(parents=True, exist_ok=True)
            
            # Setup file handler with rotation
            from logging.handlers import RotatingFileHandler
            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=file_config.get('max_size_mb', 100) * 1024 * 1024,
                backupCount=file_config.get('backup_count', 5)
            )
            
            file_level = file_config.get('level', log_level)
            file_handler.setLevel(getattr(logging, file_level, numeric_level))
            file_handler.setFormatter(JSONFormatter())
            
            root_logger.addHandler(file_handler)
            
        # Set specific logger levels
        loggers_config = config.get('loggers', {})
        for logger_name, logger_level in loggers_config.items():
            logger = logging.getLogger(logger_name)
            logger.setLevel(getattr(logging, logger_level.upper(), numeric_level))
            
    @classmethod
    def create_logger(cls, name: str) -> logging.Logger:
        """Create a logger instance"""
        if not cls._configured:
            # Use default configuration
            cls.configure({
                'level': os.environ.get('FACBT_LOG_LEVEL', 'INFO'),
                'outputs': {
                    'console': {
                        'enabled': True,
                        'colored': True
                    }
                }
            })
            
        return logging.getLogger(name)
        
    @classmethod
    def create_performance_logger(cls, name: str) -> PerformanceLogger:
        """Create a performance logger"""
        logger = cls.create_logger(name)
        return PerformanceLogger(logger)


# Context manager for timing operations
class LogTimer:
    """Context manager for logging operation timing"""
    
    def __init__(self, logger: logging.Logger, operation: str, **kwargs):
        self.logger = logger
        self.operation = operation
        self.kwargs = kwargs
        self.start_time = None
        
    def __enter__(self):
        import time
        self.start_time = time.time()
        self.logger.debug(f"Starting {self.operation}")
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        import time
        duration = time.time() - self.start_time
        
        if exc_type is None:
            self.logger.info(
                f"Completed {self.operation} in {duration:.3f}s",
                extra={'extra_fields': {
                    'performance': {
                        'operation': self.operation,
                        'duration_seconds': duration,
                        'success': True,
                        **self.kwargs
                    }
                }}
            )
        else:
            self.logger.error(
                f"Failed {self.operation} after {duration:.3f}s: {exc_val}",
                extra={'extra_fields': {
                    'performance': {
                        'operation': self.operation,
                        'duration_seconds': duration,
                        'success': False,
                        'error': str(exc_val),
                        **self.kwargs
                    }
                }}
            )


# Convenience functions
def get_logger(name: str) -> logging.Logger:
    """Get a logger instance"""
    return LoggerFactory.create_logger(name)


def log_timing(logger: logging.Logger, operation: str, **kwargs):
    """Decorator/context manager for timing operations"""
    return LogTimer(logger, operation, **kwargs)


# Setup default logging if not configured
if not LoggerFactory._configured:
    LoggerFactory.configure({
        'level': os.environ.get('FACBT_LOG_LEVEL', 'INFO'),
        'outputs': {
            'console': {
                'enabled': True,
                'colored': True
            }
        }
    })

