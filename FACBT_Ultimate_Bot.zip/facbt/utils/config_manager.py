"""
Configuration Manager - Handles loading and validation of FACBT configuration
"""

import json
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
import jsonschema

from .logger import LoggerFactory


@dataclass
class ConfigurationSchema:
    """Configuration schema definition"""
    
    @staticmethod
    def get_schema() -> Dict[str, Any]:
        """Get JSON schema for configuration validation"""
        return {
            "type": "object",
            "properties": {
                "engine": {
                    "type": "object",
                    "properties": {
                        "max_concurrent_accounts": {"type": "integer", "minimum": 1, "maximum": 20},
                        "account_creation_timeout": {"type": "integer", "minimum": 60, "maximum": 1800},
                        "retry_attempts": {"type": "integer", "minimum": 1, "maximum": 10},
                        "thread_pool_size": {"type": "integer", "minimum": 1, "maximum": 50}
                    }
                },
                "proxy": {
                    "type": "object",
                    "properties": {
                        "enabled": {"type": "boolean"},
                        "pool_size": {"type": "integer", "minimum": 10, "maximum": 1000},
                        "validation_timeout": {"type": "integer", "minimum": 5, "maximum": 60},
                        "rotation_strategy": {"type": "string", "enum": ["round_robin", "random", "weighted"]}
                    }
                },
                "email": {
                    "type": "object",
                    "properties": {
                        "service_rotation": {"type": "boolean"},
                        "email_lifetime": {"type": "integer", "minimum": 300, "maximum": 7200},
                        "verification_timeout": {"type": "integer", "minimum": 60, "maximum": 600}
                    }
                },
                "behavior": {
                    "type": "object",
                    "properties": {
                        "typing": {
                            "type": "object",
                            "properties": {
                                "speed_wpm_range": {
                                    "type": "array",
                                    "items": {"type": "integer"},
                                    "minItems": 2,
                                    "maxItems": 2
                                }
                            }
                        }
                    }
                }
            }
        }


class ConfigurationManager:
    """Manages FACBT configuration loading and validation"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.logger = LoggerFactory.create_logger(__name__)
        self.config_path = config_path
        self.config: Dict[str, Any] = {}
        self.schema = ConfigurationSchema.get_schema()
        
        # Load configuration
        self._load_configuration()
        
    def _load_configuration(self):
        """Load configuration from multiple sources"""
        try:
            # Start with default configuration
            self.config = self._get_default_config()
            
            # Load from file if specified
            if self.config_path:
                file_config = self._load_config_file(self.config_path)
                self.config = self._merge_configs(self.config, file_config)
            else:
                # Try to load from default locations
                default_paths = [
                    'config/default.json',
                    'config/facbt.json',
                    'facbt.json',
                    os.path.expanduser('~/.facbt/config.json')
                ]
                
                for path in default_paths:
                    if os.path.exists(path):
                        file_config = self._load_config_file(path)
                        self.config = self._merge_configs(self.config, file_config)
                        self.logger.info(f"Loaded configuration from: {path}")
                        break
                        
            # Override with environment variables
            env_config = self._load_environment_config()
            self.config = self._merge_configs(self.config, env_config)
            
            # Validate configuration
            self._validate_configuration()
            
            self.logger.info("Configuration loaded and validated successfully")
            
        except Exception as e:
            self.logger.error(f"Failed to load configuration: {e}")
            raise
            
    def _get_default_config(self) -> Dict[str, Any]:
        """Get default configuration"""
        return {
            "engine": {
                "max_concurrent_accounts": 3,
                "account_creation_timeout": 300,
                "retry_attempts": 3,
                "retry_delay_base": 2,
                "retry_delay_max": 60,
                "thread_pool_size": 5,
                "resource_cleanup_interval": 300,
                "health_check_interval": 60,
                "graceful_shutdown_timeout": 30
            },
            "proxy": {
                "enabled": True,
                "pool_size": 50,
                "min_pool_size": 10,
                "validation_timeout": 10,
                "validation_interval": 300,
                "rotation_strategy": "round_robin",
                "geographic_distribution": True,
                "preferred_countries": ["US", "CA", "GB", "DE", "FR"],
                "blacklisted_countries": ["CN", "RU", "IR"],
                "protocol_preference": ["http", "https", "socks5"],
                "anonymity_level": "elite",
                "max_failures_per_proxy": 3,
                "proxy_refresh_interval": 3600,
                "services": {
                    "proxyscrape": {
                        "enabled": True,
                        "timeout": 30,
                        "max_proxies": 25
                    },
                    "free_proxy_list": {
                        "enabled": True,
                        "timeout": 30,
                        "max_proxies": 25
                    }
                }
            },
            "user_agent": {
                "database_size": 1000,
                "rotation_strategy": "weighted_random",
                "browser_distribution": {
                    "chrome": 0.65,
                    "firefox": 0.15,
                    "safari": 0.12,
                    "edge": 0.08
                },
                "platform_distribution": {
                    "windows": 0.70,
                    "macos": 0.15,
                    "linux": 0.10,
                    "android": 0.05
                },
                "update_interval": 86400,
                "consistency_check": True,
                "fingerprint_randomization": {
                    "screen_resolution": True,
                    "timezone": True,
                    "language": True,
                    "plugins": True,
                    "canvas": True,
                    "webgl": True,
                    "audio": True
                }
            },
            "email": {
                "service_rotation": True,
                "email_lifetime": 3600,
                "verification_timeout": 300,
                "polling_interval": 10,
                "max_polling_attempts": 30,
                "cleanup_interval": 1800,
                "custom_emails": {
                    "enabled": True,
                    "emails": []
                },
                "services": {
                    "tempmail_org": {
                        "enabled": True,
                        "timeout": 30,
                        "rate_limit": 60,
                        "priority": 1
                    },
                    "mail_tm": {
                        "enabled": True,
                        "timeout": 30,
                        "rate_limit": 60,
                        "priority": 2
                    },
                    "guerrilla_mail": {
                        "enabled": True,
                        "timeout": 30,
                        "rate_limit": 60,
                        "priority": 3
                    }
                }
            },
            "identity": {
                "cultural_appropriateness": True,
                "geographic_consistency": True,
                "age_distribution": {
                    "min_age": 18,
                    "max_age": 65,
                    "preferred_range": [25, 45]
                },
                "gender_distribution": {
                    "male": 0.5,
                    "female": 0.5
                },
                "name_sources": ["random_user", "faker"],
                "profile_picture": {
                    "enabled": True,
                    "source": "generated",
                    "diversity": True,
                    "age_appropriate": True
                }
            },
            "behavior": {
                "typing": {
                    "speed_wpm_range": [30, 60],
                    "error_rate": 0.02,
                    "correction_probability": 0.8,
                    "pause_probability": 0.1,
                    "burst_typing": True
                },
                "mouse": {
                    "movement_speed": "natural",
                    "acceleration_curve": "human",
                    "click_precision": 0.95,
                    "double_click_interval": [100, 300],
                    "hover_probability": 0.3,
                    "hover_duration_range": [500, 2000]
                },
                "timing": {
                    "reading_speed_wpm": 200,
                    "thinking_delay_range": [1, 5],
                    "attention_span_range": [300, 1800],
                    "fatigue_factor": 0.1,
                    "circadian_rhythm": True
                },
                "interaction": {
                    "scroll_probability": 0.7,
                    "back_button_probability": 0.1,
                    "refresh_probability": 0.05,
                    "tab_switching_probability": 0.1,
                    "form_validation_delay": [2, 8]
                }
            },
            "detection": {
                "stealth_mode": True,
                "fingerprint_randomization": True,
                "behavioral_mimicking": True,
                "captcha_solving": {
                    "enabled": True,
                    "service": "manual",
                    "timeout": 120
                },
                "rate_limiting": {
                    "enabled": True,
                    "requests_per_minute": 10,
                    "burst_allowance": 3
                }
            },
            "facebook": {
                "registration_url": "https://www.facebook.com/reg/",
                "mobile_registration": False,
                "form_completion_strategy": "human_like",
                "verification_method": "email",
                "profile_completion": {
                    "enabled": True,
                    "add_profile_picture": True,
                    "add_bio": False,
                    "add_interests": False
                }
            },
            "logging": {
                "level": "INFO",
                "outputs": {
                    "console": {
                        "enabled": True,
                        "colored": True,
                        "level": "INFO"
                    },
                    "file": {
                        "enabled": True,
                        "path": "logs/facbt.log",
                        "level": "DEBUG",
                        "max_size_mb": 100,
                        "backup_count": 5
                    }
                },
                "sensitive_data_filter": True
            },
            "termux": {
                "optimizations": {
                    "memory_conservative": True,
                    "battery_optimization": True,
                    "network_efficiency": True,
                    "storage_optimization": True
                },
                "resource_limits": {
                    "max_memory_mb": 256,
                    "max_cpu_percent": 70,
                    "max_network_connections": 30,
                    "max_file_handles": 100
                },
                "background_operation": {
                    "enabled": True,
                    "wake_lock": False,
                    "notification": True,
                    "priority": "low"
                }
            }
        }
        
    def _load_config_file(self, file_path: str) -> Dict[str, Any]:
        """Load configuration from file"""
        try:
            path = Path(file_path)
            
            if not path.exists():
                raise FileNotFoundError(f"Configuration file not found: {file_path}")
                
            with open(path, 'r', encoding='utf-8') as f:
                if path.suffix.lower() in ['.yaml', '.yml']:
                    return yaml.safe_load(f) or {}
                elif path.suffix.lower() == '.json':
                    return json.load(f) or {}
                else:
                    raise ValueError(f"Unsupported configuration file format: {path.suffix}")
                    
        except Exception as e:
            self.logger.error(f"Failed to load config file {file_path}: {e}")
            raise
            
    def _load_environment_config(self) -> Dict[str, Any]:
        """Load configuration from environment variables"""
        env_config = {}
        
        # Map environment variables to config paths
        env_mappings = {
            'FACBT_LOG_LEVEL': ['logging', 'level'],
            'FACBT_MAX_ACCOUNTS': ['engine', 'max_concurrent_accounts'],
            'FACBT_PROXY_ENABLED': ['proxy', 'enabled'],
            'FACBT_PROXY_POOL_SIZE': ['proxy', 'pool_size'],
            'FACBT_TEST_MODE': ['engine', 'test_mode'],
        }
        
        for env_var, config_path in env_mappings.items():
            value = os.environ.get(env_var)
            if value is not None:
                # Convert value to appropriate type
                if value.lower() in ['true', 'false']:
                    value = value.lower() == 'true'
                elif value.isdigit():
                    value = int(value)
                elif value.replace('.', '').isdigit():
                    value = float(value)
                    
                # Set nested config value
                current = env_config
                for key in config_path[:-1]:
                    if key not in current:
                        current[key] = {}
                    current = current[key]
                current[config_path[-1]] = value
                
        return env_config
        
    def _merge_configs(self, base: Dict[str, Any], override: Dict[str, Any]) -> Dict[str, Any]:
        """Merge two configuration dictionaries"""
        result = base.copy()
        
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
                
        return result
        
    def _validate_configuration(self):
        """Validate configuration against schema"""
        try:
            jsonschema.validate(self.config, self.schema)
            
            # Additional custom validations
            self._validate_custom_rules()
            
        except jsonschema.ValidationError as e:
            self.logger.error(f"Configuration validation error: {e.message}")
            raise ValueError(f"Invalid configuration: {e.message}")
        except Exception as e:
            self.logger.error(f"Configuration validation failed: {e}")
            raise
            
    def _validate_custom_rules(self):
        """Validate custom configuration rules"""
        # Validate typing speed range
        typing_config = self.config.get('behavior', {}).get('typing', {})
        speed_range = typing_config.get('speed_wpm_range', [30, 60])
        if len(speed_range) == 2 and speed_range[0] >= speed_range[1]:
            raise ValueError("Typing speed range: minimum must be less than maximum")
            
        # Validate age distribution
        identity_config = self.config.get('identity', {})
        age_dist = identity_config.get('age_distribution', {})
        min_age = age_dist.get('min_age', 18)
        max_age = age_dist.get('max_age', 65)
        if min_age >= max_age:
            raise ValueError("Age distribution: min_age must be less than max_age")
            
        # Validate preferred age range
        pref_range = age_dist.get('preferred_range', [25, 45])
        if len(pref_range) == 2:
            if pref_range[0] < min_age or pref_range[1] > max_age:
                raise ValueError("Preferred age range must be within min_age and max_age")
                
    def get_configuration(self) -> Dict[str, Any]:
        """Get the complete configuration"""
        return self.config.copy()
        
    def get_section(self, section: str) -> Dict[str, Any]:
        """Get a specific configuration section"""
        return self.config.get(section, {}).copy()
        
    def get_value(self, path: str, default: Any = None) -> Any:
        """Get a configuration value by dot-separated path"""
        keys = path.split('.')
        current = self.config
        
        for key in keys:
            if isinstance(current, dict) and key in current:
                current = current[key]
            else:
                return default
                
        return current
        
    def set_value(self, path: str, value: Any):
        """Set a configuration value by dot-separated path"""
        keys = path.split('.')
        current = self.config
        
        for key in keys[:-1]:
            if key not in current:
                current[key] = {}
            current = current[key]
            
        current[keys[-1]] = value
        
    def save_configuration(self, file_path: Optional[str] = None):
        """Save current configuration to file"""
        if not file_path:
            file_path = self.config_path or 'config/current.json'
            
        try:
            path = Path(file_path)
            path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(path, 'w', encoding='utf-8') as f:
                if path.suffix.lower() in ['.yaml', '.yml']:
                    yaml.dump(self.config, f, default_flow_style=False, indent=2)
                else:
                    json.dump(self.config, f, indent=2, ensure_ascii=False)
                    
            self.logger.info(f"Configuration saved to: {file_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to save configuration: {e}")
            raise
            
    def reload_configuration(self):
        """Reload configuration from sources"""
        self._load_configuration()
        
    def is_termux_environment(self) -> bool:
        """Check if running in Termux environment"""
        return "com.termux" in os.environ.get("PREFIX", "")
        
    def get_termux_optimized_config(self) -> Dict[str, Any]:
        """Get Termux-optimized configuration"""
        if self.is_termux_environment():
            termux_config = self.get_section('termux')
            
            # Apply Termux optimizations
            optimized = self.config.copy()
            
            if termux_config.get('optimizations', {}).get('memory_conservative', True):
                optimized['engine']['max_concurrent_accounts'] = min(
                    optimized['engine']['max_concurrent_accounts'], 2
                )
                optimized['proxy']['pool_size'] = min(
                    optimized['proxy']['pool_size'], 30
                )
                
            if termux_config.get('optimizations', {}).get('network_efficiency', True):
                optimized['proxy']['validation_timeout'] = 5
                optimized['email']['verification_timeout'] = 180
                
            return optimized
            
        return self.config
        
    def validate_and_fix(self) -> List[str]:
        """Validate configuration and fix common issues"""
        issues_fixed = []
        
        try:
            # Fix typing speed range if invalid
            typing_config = self.config.get('behavior', {}).get('typing', {})
            speed_range = typing_config.get('speed_wpm_range', [30, 60])
            if len(speed_range) == 2 and speed_range[0] >= speed_range[1]:
                typing_config['speed_wpm_range'] = [30, 60]
                issues_fixed.append("Fixed invalid typing speed range")
                
            # Fix age distribution if invalid
            identity_config = self.config.get('identity', {})
            age_dist = identity_config.get('age_distribution', {})
            if age_dist.get('min_age', 18) >= age_dist.get('max_age', 65):
                age_dist['min_age'] = 18
                age_dist['max_age'] = 65
                issues_fixed.append("Fixed invalid age distribution")
                
            # Validate again
            self._validate_configuration()
            
        except Exception as e:
            self.logger.warning(f"Could not fix configuration issues: {e}")
            
        return issues_fixed

