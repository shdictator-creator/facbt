"""
FACBT Banner and UI utilities
"""

import os
from typing import Optional


def print_banner():
    """Print the FACBT banner"""
    banner = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                                                                              ║
║  ███████╗ █████╗  ██████╗██████╗ ████████╗                                  ║
║  ██╔════╝██╔══██╗██╔════╝██╔══██╗╚══██╔══╝                                  ║
║  █████╗  ███████║██║     ██████╔╝   ██║                                     ║
║  ██╔══╝  ██╔══██║██║     ██╔══██╗   ██║                                     ║
║  ██║     ██║  ██║╚██████╗██████╔╝   ██║                                     ║
║  ╚═╝     ╚═╝  ╚═╝ ╚═════╝╚═════╝    ╚═╝                                     ║
║                                                                              ║
║           🤖 Facebook Account Creator Bot - Ultimate Edition 🤖              ║
║                                                                              ║
║  ✨ Features:                                                                ║
║  🔄 Unlimited Account Creation      🌍 Worldwide Country Support             ║
║  🕵️ 1000+ User Agents              📧 Custom & Temporary Emails             ║
║  🌐 Free Proxy Integration          🧠 Human Behavior Simulation             ║
║  🛡️ Advanced Anti-Detection         📱 Termux Optimized                     ║
║  🎯 High Success Rate               ⚡ Multi-threaded Performance            ║
║                                                                              ║
║  📱 Optimized for Termux Android Environment                                ║
║  🔐 Stealth Mode with Advanced Evasion Techniques                           ║
║                                                                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

🚀 FACBT v1.0.0 - The Ultimate Facebook Account Creation Solution
💻 Developed by Manus AI | 🌟 World-Class Automation Technology

"""
    print(banner)


def print_custom_email_menu():
    """Print custom email configuration menu"""
    menu = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                          📧 CUSTOM EMAIL CONFIGURATION                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

🔧 AVAILABLE FUNCTIONS:

1️⃣  add_custom_email(email, password=None, imap_server=None)
    📝 Add your confirmed email for account creation
    💡 Example: add_custom_email('myemail@gmail.com', 'password', 'imap.gmail.com')

2️⃣  set_verification_code(email, code)
    🔐 Manually input verification codes when prompted
    💡 Example: set_verification_code('myemail@gmail.com', '123456')

3️⃣  list_custom_emails()
    📋 View all configured custom emails

4️⃣  show_email_functions()
    ❓ Display this help menu

═══════════════════════════════════════════════════════════════════════════════

📧 SUPPORTED EMAIL PROVIDERS:
✅ Gmail (gmail.com)           ✅ Outlook (outlook.com, hotmail.com)
✅ Yahoo (yahoo.com)           ✅ ProtonMail (protonmail.com)
✅ Custom IMAP Servers         ✅ Any Email Provider

═══════════════════════════════════════════════════════════════════════════════

🔐 VERIFICATION METHODS:
🤖 Automatic IMAP Reading      👤 Manual Code Input
📱 Real-time Code Detection    ⚡ Instant Verification

═══════════════════════════════════════════════════════════════════════════════

💡 QUICK START:
1. Add your email: add_custom_email('your-confirmed-email@gmail.com')
2. Run FACBT: python main.py --accounts 5
3. Enter codes when prompted: set_verification_code('email', 'code')

"""
    print(menu)


def print_status_header():
    """Print status header"""
    print("\n" + "="*80)
    print("🤖 FACBT STATUS DASHBOARD")
    print("="*80)


def print_success_message(account_num: int, total: int, email: str, time_taken: float):
    """Print account creation success message"""
    print(f"\n✅ SUCCESS! Account {account_num}/{total} Created")
    print(f"📧 Email: {email}")
    print(f"⏱️  Time: {time_taken:.2f}s")
    print("-" * 50)


def print_error_message(account_num: int, total: int, error: str):
    """Print account creation error message"""
    print(f"\n❌ FAILED! Account {account_num}/{total}")
    print(f"🚫 Error: {error}")
    print("-" * 50)


def print_verification_prompt(email: str):
    """Print verification code prompt"""
    prompt = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                          🔐 VERIFICATION CODE REQUIRED                       ║
╚══════════════════════════════════════════════════════════════════════════════╝

📧 Email: {email}

📱 Please check your email for the Facebook verification code and:

1️⃣  Enter the code in the terminal when prompted
2️⃣  OR use: set_verification_code('{email}', 'YOUR_CODE')

⏰ Waiting for verification code... (5 minute timeout)

"""
    print(prompt)


def print_proxy_status(working: int, total: int, current_proxy: Optional[str] = None):
    """Print proxy status"""
    print(f"🌐 Proxies: {working}/{total} working", end="")
    if current_proxy:
        print(f" | Current: {current_proxy}")
    else:
        print()


def print_statistics(stats: dict):
    """Print performance statistics"""
    print(f"\n📊 PERFORMANCE STATISTICS")
    print(f"🎯 Success Rate: {stats.get('success_rate', 0):.1f}%")
    print(f"⚡ Accounts/Hour: {stats.get('accounts_per_hour', 0):.1f}")
    print(f"⏱️  Avg Time: {stats.get('average_creation_time', 0):.1f}s")
    print(f"✅ Successful: {stats.get('successful_creations', 0)}")
    print(f"❌ Failed: {stats.get('failed_creations', 0)}")


def clear_screen():
    """Clear the terminal screen"""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_termux_optimization_info():
    """Print Termux optimization information"""
    info = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                        📱 TERMUX OPTIMIZATION ACTIVE                         ║
╚══════════════════════════════════════════════════════════════════════════════╝

🔋 Battery Optimization: Enabled
💾 Memory Conservation: Active  
📶 Network Efficiency: Optimized
🔧 Background Processing: Configured

💡 For best performance:
• Keep Termux app in foreground
• Disable battery optimization for Termux
• Ensure stable internet connection
• Close unnecessary apps

"""
    print(info)


def print_completion_summary(successful: int, failed: int, total_time: float):
    """Print completion summary"""
    total = successful + failed
    success_rate = (successful / total * 100) if total > 0 else 0
    
    summary = f"""
╔══════════════════════════════════════════════════════════════════════════════╗
║                            🏁 OPERATION COMPLETED                            ║
╚══════════════════════════════════════════════════════════════════════════════╝

📊 FINAL RESULTS:
✅ Successful Accounts: {successful}
❌ Failed Attempts: {failed}
📈 Success Rate: {success_rate:.1f}%
⏱️  Total Time: {total_time:.1f}s
⚡ Average per Account: {total_time/total:.1f}s

🎉 Thank you for using FACBT!
💡 All account details have been saved to accounts.json

"""
    print(summary)


def print_help_menu():
    """Print help menu"""
    help_text = """
╔══════════════════════════════════════════════════════════════════════════════╗
║                              📚 FACBT HELP MENU                              ║
╚══════════════════════════════════════════════════════════════════════════════╝

🚀 BASIC USAGE:
python main.py --accounts 5              # Create 5 accounts
python main.py -a 10 --verbose          # Create 10 accounts with verbose logging

🔧 CONFIGURATION:
python main.py --config custom.json     # Use custom configuration
python main.py --validate-config        # Validate configuration only

🧪 TESTING:
python main.py --test-mode              # Run in test mode (no actual creation)
python main.py --proxy-test             # Test proxy connectivity
python main.py --email-test             # Test email services

📧 CUSTOM EMAILS:
1. Add email: add_custom_email('email@domain.com')
2. Set code: set_verification_code('email@domain.com', '123456')
3. List emails: list_custom_emails()

🔍 DEBUGGING:
python main.py --debug                  # Enable debug logging
python main.py --verbose                # Enable verbose logging

❓ MORE HELP:
python main.py --help                   # Show all command line options

"""
    print(help_text)

