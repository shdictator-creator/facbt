"""
Mail.tm Service - Temporary email service integration
"""

import aiohttp
import asyncio
import time
from typing import Dict, List, Optional, Any

from utils.logger import LoggerFactory


class MailTmService:
    """Mail.tm temporary email service"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        self.base_url = "https://api.mail.tm"
        self.timeout = config.get('timeout', 30)
        self.token = None
        
    async def get_temporary_email(self) -> Optional[str]:
        """Get a temporary email address"""
        try:
            # Get available domains
            domains = await self._get_domains()
            if not domains:
                return None
                
            domain = domains[0]['domain']
            
            # Create account
            account_data = {
                'address': f"user{int(time.time())}@{domain}",
                'password': 'temppassword123'
            }
            
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/accounts"
                async with session.post(url, json=account_data, timeout=self.timeout) as response:
                    if response.status == 201:
                        data = await response.json()
                        return data.get('address')
                        
        except Exception as e:
            self.logger.error(f"Mail.tm get email failed: {e}")
        return None
        
    async def _get_domains(self) -> List[Dict[str, Any]]:
        """Get available domains"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/domains"
                async with session.get(url, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('hydra:member', [])
        except Exception as e:
            self.logger.error(f"Mail.tm get domains failed: {e}")
        return []
        
    async def get_emails(self, email: str) -> List[Dict[str, Any]]:
        """Get emails for the temporary address"""
        try:
            if not self.token:
                await self._authenticate(email)
                
            async with aiohttp.ClientSession() as session:
                headers = {'Authorization': f'Bearer {self.token}'}
                url = f"{self.base_url}/messages"
                async with session.get(url, headers=headers, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('hydra:member', [])
        except Exception as e:
            self.logger.error(f"Mail.tm get emails failed: {e}")
        return []
        
    async def _authenticate(self, email: str):
        """Authenticate with the service"""
        try:
            auth_data = {
                'address': email,
                'password': 'temppassword123'
            }
            
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/token"
                async with session.post(url, json=auth_data, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.token = data.get('token')
        except Exception as e:
            self.logger.error(f"Mail.tm authentication failed: {e}")
            
    async def health_check(self) -> bool:
        """Check service health"""
        try:
            domains = await self._get_domains()
            return len(domains) > 0
        except:
            return False

