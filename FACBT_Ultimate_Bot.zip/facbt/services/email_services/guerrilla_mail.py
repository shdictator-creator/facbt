"""
Guerrilla Mail Service - Temporary email service integration
"""

import aiohttp
import asyncio
import time
import random
from typing import Dict, List, Optional, Any

from utils.logger import LoggerFactory


class GuerrillaMailService:
    """Guerrilla Mail temporary email service"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        self.base_url = "https://api.guerrillamail.com/ajax.php"
        self.timeout = config.get('timeout', 30)
        self.session_id = None
        
    async def get_temporary_email(self) -> Optional[str]:
        """Get a temporary email address"""
        try:
            async with aiohttp.ClientSession() as session:
                params = {
                    'f': 'get_email_address',
                    'lang': 'en'
                }
                
                async with session.get(self.base_url, params=params, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        self.session_id = data.get('sid_token')
                        return data.get('email_addr')
                        
        except Exception as e:
            self.logger.error(f"Guerrilla Mail get email failed: {e}")
        return None
        
    async def get_emails(self, email: str) -> List[Dict[str, Any]]:
        """Get emails for the temporary address"""
        try:
            if not self.session_id:
                return []
                
            async with aiohttp.ClientSession() as session:
                params = {
                    'f': 'get_email_list',
                    'sid_token': self.session_id,
                    'offset': 0
                }
                
                async with session.get(self.base_url, params=params, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get('list', [])
                        
        except Exception as e:
            self.logger.error(f"Guerrilla Mail get emails failed: {e}")
        return []
        
    async def health_check(self) -> bool:
        """Check service health"""
        try:
            test_email = await self.get_temporary_email()
            return test_email is not None
        except:
            return False

