"""
TempMail.org Service - Temporary email service integration
"""

import aiohttp
import asyncio
import time
from typing import Dict, List, Optional, Any

from utils.logger import LoggerFactory


class TempMailOrgService:
    """TempMail.org temporary email service"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = LoggerFactory.create_logger(__name__)
        self.base_url = "https://api.tempmail.org/request"
        self.timeout = config.get('timeout', 30)
        
    async def get_temporary_email(self) -> Optional[str]:
        """Get a temporary email address"""
        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/mail/id/"
                async with session.get(url, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.text()
                        return data.strip()
        except Exception as e:
            self.logger.error(f"TempMail.org get email failed: {e}")
        return None
        
    async def get_emails(self, email: str) -> List[Dict[str, Any]]:
        """Get emails for the temporary address"""
        try:
            email_id = email.split('@')[0]
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/mail/id/{email_id}/"
                async with session.get(url, timeout=self.timeout) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data if isinstance(data, list) else []
        except Exception as e:
            self.logger.error(f"TempMail.org get emails failed: {e}")
        return []
        
    async def health_check(self) -> bool:
        """Check service health"""
        try:
            test_email = await self.get_temporary_email()
            return test_email is not None
        except:
            return False

